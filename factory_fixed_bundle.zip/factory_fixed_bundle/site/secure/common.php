<?php
declare(strict_types=1);
date_default_timezone_set('UTC');
$KEYCLOAK_BASE = getenv('KEYCLOAK_BASE') ?: 'http://127.0.0.1:8080';
$REALM = getenv('FACTORY_REALM') ?: 'FactoryRealm';
$ADMIN_CLIENT_ID = getenv('ADMIN_CLIENT_ID') ?: 'app-admin';
$ADMIN_CLIENT_SECRET = getenv('ADMIN_CLIENT_SECRET') ?: 'PASTE_APP_ADMIN_CLIENT_SECRET_HERE';
$DATA_DIR = __DIR__ . '/../data'; if (!is_dir($DATA_DIR)) @mkdir($DATA_DIR,0775,true);
$DB_PATH = $DATA_DIR . '/app.db';
function db(): PDO { global $DB_PATH; static $pdo=null; if($pdo===null){ $pdo=new PDO('sqlite:'.$DB_PATH); $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
$pdo->exec('CREATE TABLE IF NOT EXISTS kyc_requests (sub TEXT PRIMARY KEY, username TEXT, desired_role TEXT, status TEXT, reason TEXT, doc_path TEXT, created_at TEXT, updated_at TEXT)');
$pdo->exec('CREATE TABLE IF NOT EXISTS admin_sec (sub TEXT PRIMARY KEY, question TEXT, answer_hash TEXT, verified INTEGER DEFAULT 0)'); } return $pdo; }
function claim($name,$default=null){ $k='OIDC_CLAIM_'.$name; if(isset($_SERVER[$k])) return $_SERVER[$k]; return $default; }
function realm_roles(): array { $ra = claim('realm_access',''); if($ra){ $decoded = json_decode($ra, true); if(json_last_error()===JSON_ERROR_NONE && isset($decoded['roles']) && is_array($decoded['roles'])){ return $decoded['roles']; } }
 $r = claim('roles',''); if($r){ if(is_string($r)){ return array_values(array_filter(array_map('trim', preg_split('/[,\s]+/',$r)))); } if(is_array($r)) return $r; }
 if(isset($_SERVER['OIDC_CLAIM_roles'])){ $raw = $_SERVER['OIDC_CLAIM_roles']; if(is_string($raw)) return array_values(array_filter(array_map('trim', preg_split('/[,\s]+/',$raw)))); } return []; }
function has_role($r): bool { return in_array($r, realm_roles(), true); }
function require_role($r){ if(!has_role($r)){ http_response_code(403); echo "Forbidden - need role: $r"; exit; } }
function kc_admin_token(): string { global $KEYCLOAK_BASE,$REALM,$ADMIN_CLIENT_ID,$ADMIN_CLIENT_SECRET; if($ADMIN_CLIENT_SECRET==='PASTE_APP_ADMIN_CLIENT_SECRET_HERE') throw new Exception('ADMIN_CLIENT_SECRET not set in common.php'); $url = $KEYCLOAK_BASE . '/realms/' . rawurlencode($REALM) . '/protocol/openid-connect/token'; $post = http_build_query(['grant_type'=>'client_credentials','client_id'=>$ADMIN_CLIENT_ID,'client_secret'=>$ADMIN_CLIENT_SECRET]); $opts=['http'=>['method'=>'POST','header'=>"Content-Type: application/x-www-form-urlencoded\r\n",'content'=>$post,'ignore_errors'=>true]]; $resp = @file_get_contents($url,false, stream_context_create($opts)); if($resp===false) throw new Exception('Failed to fetch admin token'); $j=json_decode($resp,true); if(!isset($j['access_token'])) throw new Exception('No admin access token'); return $j['access_token']; }
function http_json($method,$url,$token,$payload=null){ $headers = "Authorization: Bearer $token\r\nContent-Type: application/json\r\n"; $opts=['http'=>['method'=>$method,'header'=>$headers,'ignore_errors'=>true]]; if($payload!==null) $opts['http']['content']=json_encode($payload); $ctx=stream_context_create($opts); $resp=@file_get_contents($url,false,$ctx); $code=0; if(isset($http_response_header[0]) && preg_match('~\s(\d{3})\s~',$http_response_header[0],$m)) $code=(int)$m[1]; return [$code,$resp]; }
function kc_role_representation($role_name){ global $KEYCLOAK_BASE,$REALM; $token=kc_admin_token(); $url = $KEYCLOAK_BASE . '/admin/realms/' . rawurlencode($REALM) . '/roles/' . rawurlencode($role_name); [$code,$resp] = http_json('GET',$url,$token); if($code!==200) throw new Exception("Failed to fetch role $role_name ($code)"); return json_decode($resp,true); }
function kc_add_realm_role_to_user_by_id($user_id,$role_rep){ global $KEYCLOAK_BASE,$REALM; $token=kc_admin_token(); $url = $KEYCLOAK_BASE . '/admin/realms/' . rawurlencode($REALM) . '/users/' . rawurlencode($user_id) . '/role-mappings/realm'; [$code,$resp] = http_json('POST',$url,$token,[$role_rep]); return $code; }
function kc_remove_realm_role_from_user_by_id($user_id,$role_rep){ global $KEYCLOAK_BASE,$REALM; $token=kc_admin_token(); $url = $KEYCLOAK_BASE . '/admin/realms/' . rawurlencode($REALM) . '/users/' . rawurlencode($user_id) . '/role-mappings/realm'; [$code,$resp] = http_json('DELETE',$url,$token,[$role_rep]); return $code; }
function kc_set_required_action_configure_totp($user_id){ global $KEYCLOAK_BASE,$REALM; $token=kc_admin_token(); $url = $KEYCLOAK_BASE . '/admin/realms/' . rawurlencode($REALM) . '/users/' . rawurlencode($user_id); [$c,$r] = http_json('GET',$url,$token); if($c!==200) throw new Exception("Failed to get user"); $user = json_decode($r,true); $actions = $user['requiredActions'] ?? []; if(!in_array('CONFIGURE_TOTP',$actions,true)){ $actions[]='CONFIGURE_TOTP'; $user['requiredActions']=$actions; [$c2,$r2]=http_json('PUT',$url,$token,$user); if(!in_array($c2,[200,204],true)) throw new Exception("Failed set required action"); } return true; }
function now_iso(){ return gmdate('Y-m-d\TH:i:s\Z'); }
?>