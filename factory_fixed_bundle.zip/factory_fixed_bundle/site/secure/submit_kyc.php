<?php require __DIR__ . '/common.php'; $user = $_SERVER['REMOTE_USER'] ?? claim('preferred_username',''); $sub = claim('sub','');
if(!$sub){ http_response_code(400); echo "Missing"; exit; } if(!isset($_FILES['kyc_doc'])||$_FILES['kyc_doc']['error']!==UPLOAD_ERR_OK){ http_response_code(400); echo "Upload error"; exit; }
$ext=strtolower(pathinfo($_FILES['kyc_doc']['name'],PATHINFO_EXTENSION)); if($ext!=='pdf'){ http_response_code(400); echo "Only PDF"; exit; }
$dir=__DIR__.'/../data/kyc/'.preg_replace('~[^a-zA-Z0-9_-]~','_',$sub); @mkdir($dir,0770,true); $dest=$dir.'/kyc_'.time().'.pdf';
if(!move_uploaded_file($_FILES['kyc_doc']['tmp_name'],$dest)){ http_response_code(500); echo "Failed"; exit; }
$pdo=db(); $ts=now_iso(); $stmt=$pdo->prepare('INSERT INTO kyc_requests(sub,username,desired_role,status,reason,doc_path,created_at,updated_at) VALUES(:sub,:user,:role,"pending","",:doc,:ts,:ts) ON CONFLICT(sub) DO UPDATE SET desired_role=excluded.desired_role,status="pending",reason="",doc_path=excluded.doc_path,updated_at=excluded.updated_at');
$stmt->execute([':sub'=>$sub,':user'=>$user,':role'=>'manufacture',':doc'=>$dest,':ts'=>$ts]); header('Location: /secure/kyc.php'); exit; ?>