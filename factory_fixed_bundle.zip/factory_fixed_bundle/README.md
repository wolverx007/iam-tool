Factory Fixed Bundle — fixes applied
Fixes included:
- Ensure realm roles are mapped into ID and access tokens (protocol mapper added) so Apache/PHP see roles.
- Apache vhost adjusted to set REMOTE_USER from preferred_username and to allow state cookie during HTTP testing.
- post-login router reads realm_access JSON claim first and routes correctly:
  - admin -> admin dashboard (requires app-level security question + Keycloak TOTP forced)
  - manufacture/kyc_pending -> KYC Center -> admin approve -> manufacture dashboard after approval and TOTP setup
  - employee -> employee dashboard
- Logout links added to landing pages.
Deploy same as before. Demo creds: admin1/AdminPass123, manuf1/ManufPass123, emp1/EmpPass123
