#!/usr/bin/env bash
set -euo pipefail
KC_HOME="/opt/keycloak"
KC_HTTP_PORT="${KC_HTTP_PORT:-8080}"
REALM="${REALM:-FactoryRealm}"
ADMIN_USER="${ADMIN_USER:-admin}"
ADMIN_PASS="${ADMIN_PASS:-Admin123!}"

${KC_HOME}/bin/kcadm.sh config credentials --server "http://127.0.0.1:${KC_HTTP_PORT}" --realm master --user "${ADMIN_USER}" --password "${ADMIN_PASS}"

if ! ${KC_HOME}/bin/kcadm.sh get realms/${REALM} >/dev/null 2>&1; then
  ${KC_HOME}/bin/kcadm.sh create realms -s realm="${REALM}" -s enabled=true -s registrationAllowed=true -s loginWithEmailAllowed=true
fi

for role in admin manufacture employee kyc_pending; do
  ${KC_HOME}/bin/kcadm.sh create roles -r "${REALM}" -s name="${role}" >/dev/null 2>&1 || true
done

if ! ${KC_HOME}/bin/kcadm.sh get clients -r "${REALM}" -q clientId="apache-site" | jq -e '.[0].id' >/dev/null; then
  cat >/tmp/webclient.json <<JSON
{ "clientId": "apache-site", "protocol": "openid-connect", "publicClient": false, "standardFlowEnabled": true,
  "directAccessGrantsEnabled": false, "serviceAccountsEnabled": false, "enabled": true,
  "redirectUris": ["http://192.168.1.12/secure/redirect_uri","http://192.168.1.12/*"],
  "webOrigins": ["+"], "attributes": {"post.logout.redirect.uris":"+","pkce.code.challenge.method":"S256"}
}
JSON
  ${KC_HOME}/bin/kcadm.sh create clients -r "${REALM}" -f /tmp/webclient.json
fi
WEB_UUID=$(${KC_HOME}/bin/kcadm.sh get clients -r "${REALM}" -q clientId="apache-site" | jq -r '.[0].id')

cat >/tmp/mapper.json <<JSON
{
  "name": "realm-roles",
  "protocol": "openid-connect",
  "protocolMapper": "oidc-usermodel-realm-role-mapper",
  "consentRequired": false,
  "config": {
    "claim.name": "realm_access",
    "jsonType.label": "JSON",
    "userinfo.token.claim": "true",
    "id.token.claim": "true",
    "access.token.claim": "true"
  }
}
JSON
if ! ${KC_HOME}/bin/kcadm.sh get clients/${WEB_UUID}/protocol-mappers/models -r "${REALM}" | jq -e '.[] | select(.name=="realm-roles")' >/dev/null 2>&1; then
  ${KC_HOME}/bin/kcadm.sh create clients/${WEB_UUID}/protocol-mappers/models -r "${REALM}" -f /tmp/mapper.json
fi

WEB_SECRET_JSON=$(${KC_HOME}/bin/kcadm.sh get clients/${WEB_UUID}/client-secret -r "${REALM}")
WEB_SECRET=$(echo "${WEB_SECRET_JSON}" | jq -r '.value')
echo -n "${WEB_SECRET}" > /root/keycloak_apache_client_secret.txt
chmod 600 /root/keycloak_apache_client_secret.txt

if ! ${KC_HOME}/bin/kcadm.sh get clients -r "${REALM}" -q clientId="app-admin" | jq -e '.[0].id' >/dev/null; then
  cat >/tmp/appadmin.json <<JSON
{ "clientId": "app-admin", "protocol": "openid-connect", "publicClient": false, "serviceAccountsEnabled": true,
  "standardFlowEnabled": false, "directAccessGrantsEnabled": false, "enabled": true }
JSON
  ${KC_HOME}/bin/kcadm.sh create clients -r "${REALM}" -f /tmp/appadmin.json
fi
APP_UUID=$(${KC_HOME}/bin/kcadm.sh get clients -r "${REALM}" -q clientId="app-admin" | jq -r '.[0].id')
APP_SECRET_JSON=$(${KC_HOME}/bin/kcadm.sh get clients/${APP_UUID}/client-secret -r "${REALM}")
APP_SECRET=$(echo "${APP_SECRET_JSON}" | jq -r '.value')
echo -n "${APP_SECRET}" > /root/keycloak_app_admin_client_secret.txt
chmod 600 /root/keycloak_app_admin_client_secret.txt

REALM_MGMT_CLIENT_ID=$(${KC_HOME}/bin/kcadm.sh get clients -r "${REALM}" -q clientId=realm-management | jq -r '.[0].id')
SA_USER_ID=$(${KC_HOME}/bin/kcadm.sh get clients/${APP_UUID}/service-account-user -r "${REALM}" | jq -r '.id')
${KC_HOME}/bin/kcadm.sh add-roles -r "${REALM}" --uid "${SA_USER_ID}" --cclientid realm-management --rolename manage-users || true
${KC_HOME}/bin/kcadm.sh add-roles -r "${REALM}" --uid "${SA_USER_ID}" --cclientid realm-management --rolename view-users || true

if ! ${KC_HOME}/bin/kcadm.sh get users -r "${REALM}" -q username="admin1" | jq -e '.[0].id' >/dev/null; then
  ${KC_HOME}/bin/kcadm.sh create users -r "${REALM}" -s username="admin1" -s enabled=true -s email="admin1@example.com"
  AID=$(${KC_HOME}/bin/kcadm.sh get users -r "${REALM}" -q username="admin1" | jq -r '.[0].id')
  ${KC_HOME}/bin/kcadm.sh set-password -r "${REALM}" --username admin1 --new-password "AdminPass123"
  ${KC_HOME}/bin/kcadm.sh add-roles -r "${REALM}" --uusername "admin1" --rolename "admin"
  ${KC_HOME}/bin/kcadm.sh update users/${AID} -r "${REALM}" -s requiredActions='["CONFIGURE_TOTP"]' || true
fi

if ! ${KC_HOME}/bin/kcadm.sh get users -r "${REALM}" -q username="manuf1" | jq -e '.[0].id' >/dev/null; then
  ${KC_HOME}/bin/kcadm.sh create users -r "${REALM}" -s username="manuf1" -s enabled=true -s email="manuf1@example.com"
  ${KC_HOME}/bin/kcadm.sh set-password -r "${REALM}" --username manuf1 --new-password "ManufPass123"
  ${KC_HOME}/bin/kcadm.sh add-roles -r "${REALM}" --uusername "manuf1" --rolename "kyc_pending"
fi

if ! ${KC_HOME}/bin/kcadm.sh get users -r "${REALM}" -q username="emp1" | jq -e '.[0].id' >/dev/null; then
  ${KC_HOME}/bin/kcadm.sh create users -r "${REALM}" -s username="emp1" -s enabled=true -s email="emp1@example.com"
  ${KC_HOME}/bin/kcadm.sh set-password -r "${REALM}" --username emp1 --new-password "EmpPass123"
  ${KC_HOME}/bin/kcadm.sh add-roles -r "${REALM}" --uusername "emp1" --rolename "employee"
fi

echo "Done. apache-site secret: $(cat /root/keycloak_apache_client_secret.txt)"
echo "app-admin secret: $(cat /root/keycloak_app_admin_client_secret.txt)"
