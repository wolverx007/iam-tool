"""
Authentication service for IAM Tool
"""
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_
import secrets
import logging

from models import User, UserSession, AuthFactor, PasswordResetToken, SessionStatus, AALLevel
from services.security import SecurityService
from services.vault import VaultService
from services.totp import TOTPService
from services.webauthn import WebAuthnService
from services.email import EmailService
from config import get_settings

logger = logging.getLogger(__name__)

class AuthenticationResult:
    def __init__(self, success: bool = False, user: Optional[User] = None, 
                 message: str = "", requires_mfa: bool = False, 
                 mfa_methods: List[str] = None, temp_token: str = ""):
        self.success = success
        self.user = user
        self.message = message
        self.requires_mfa = requires_mfa
        self.mfa_methods = mfa_methods or []
        self.temp_token = temp_token

class AuthService:
    def __init__(self, db: Session):
        self.db = db
        self.security = SecurityService()
        self.vault = VaultService()
        self.totp = TOTPService()
        self.webauthn = WebAuthnService()
        self.email = EmailService()
        self.settings = get_settings()
    
    async def authenticate_user(self, username: str, password: str, 
                              project_name: str, client_ip: str, 
                              user_agent: str) -> AuthenticationResult:
        """Authenticate user with username and password"""
        try:
            # Find user by username and project
            user = self.db.query(User).join(User.project).filter(
                User.username == username,
                User.project.has(name=project_name),
                User.is_active == True
            ).first()
            
            if not user:
                logger.warning(f"Authentication failed: User {username} not found in project {project_name}")
                return AuthenticationResult(
                    success=False,
                    message="Invalid username, password, or project"
                )
            
            # Check if user is locked
            if user.locked_until and user.locked_until > datetime.utcnow():
                remaining = (user.locked_until - datetime.utcnow()).seconds
                return AuthenticationResult(
                    success=False,
                    message=f"Account locked. Try again in {remaining // 60} minutes"
                )
            
            # Verify password
            if not self.security.verify_password(password, user.password_hash):
                # Increment failed attempts
                user.failed_login_attempts += 1
                
                # Lock account if too many failures
                if user.failed_login_attempts >= self.settings.security.max_login_attempts:
                    user.locked_until = datetime.utcnow() + timedelta(
                        seconds=self.settings.security.lockout_duration
                    )
                    logger.warning(f"User {username} locked due to failed login attempts")
                
                self.db.commit()
                
                return AuthenticationResult(
                    success=False,
                    message="Invalid username, password, or project"
                )
            
            # Reset failed attempts on successful password verification
            user.failed_login_attempts = 0
            user.locked_until = None
            
            # Check if MFA is required based on role AAL level
            required_aal = user.role.aal_level
            if required_aal in [AALLevel.AAL2, AALLevel.AAL3]:
                # Get available MFA methods for user
                mfa_factors = self.db.query(AuthFactor).filter(
                    AuthFactor.user_id == user.id,
                    AuthFactor.is_active == True
                ).all()
                
                if not mfa_factors:
                    return AuthenticationResult(
                        success=False,
                        message=f"MFA is required for your role but no methods are configured. Please contact your administrator."
                    )
                
                # Generate temporary token for MFA process
                temp_token = secrets.token_urlsafe(32)
                await self.vault.store_temp_token(temp_token, {
                    'user_id': str(user.id),
                    'client_ip': client_ip,
                    'user_agent': user_agent,
                    'expires': (datetime.utcnow() + timedelta(minutes=5)).isoformat()
                })
                
                mfa_methods = [factor.factor_type for factor in mfa_factors]
                
                return AuthenticationResult(
                    success=True,
                    user=user,
                    requires_mfa=True,
                    mfa_methods=mfa_methods,
                    temp_token=temp_token,
                    message="Additional authentication required"
                )
            
            # Update last login
            user.last_login = datetime.utcnow()
            self.db.commit()
            
            return AuthenticationResult(
                success=True,
                user=user,
                message="Authentication successful"
            )
            
        except Exception as e:
            logger.error(f"Authentication error: {e}")
            return AuthenticationResult(
                success=False,
                message="Authentication failed"
            )
    
    async def verify_totp(self, temp_token: str, totp_code: str, 
                         client_ip: str, user_agent: str) -> Dict[str, Any]:
        """Verify TOTP code for MFA"""
        try:
            # Retrieve temp token data
            temp_data = await self.vault.get_temp_token(temp_token)
            if not temp_data:
                return {
                    'success': False,
                    'message': 'Invalid or expired token'
                }
            
            # Check if token expired
            expires = datetime.fromisoformat(temp_data['expires'])
            if datetime.utcnow() > expires:
                await self.vault.delete_temp_token(temp_token)
                return {
                    'success': False,
                    'message': 'Token expired'
                }
            
            # Get user
            user = self.db.query(User).filter(User.id == temp_data['user_id']).first()
            if not user:
                return {
                    'success': False,
                    'message': 'User not found'
                }
            
            # Get TOTP factor
            totp_factor = self.db.query(AuthFactor).filter(
                AuthFactor.user_id == user.id,
                AuthFactor.factor_type == 'totp',
                AuthFactor.is_active == True
            ).first()
            
            if not totp_factor:
                return {
                    'success': False,
                    'message': 'TOTP not configured'
                }
            
            # Verify TOTP code
            totp_secret = await self.vault.get_totp_secret(str(totp_factor.id))
            if not self.totp.verify_code(totp_secret, totp_code):
                return {
                    'success': False,
                    'message': 'Invalid TOTP code'
                }
            
            # Create session
            session = await self.create_session(user, client_ip, user_agent)
            
            # Clean up temp token
            await self.vault.delete_temp_token(temp_token)
            
            # Update last login
            user.last_login = datetime.utcnow()
            self.db.commit()
            
            return {
                'success': True,
                'access_token': session.session_token,
                'refresh_token': session.refresh_token,
                'expires_in': self.security.get_session_timeout(),
                'user_id': str(user.id),
                'username': user.username,
                'role': user.role.name,
                'aal_level': user.role.aal_level.value
            }
            
        except Exception as e:
            logger.error(f"TOTP verification error: {e}")
            return {
                'success': False,
                'message': 'Verification failed'
            }
    
    async def create_session(self, user: User, client_ip: str, 
                           user_agent: str) -> UserSession:
        """Create a new user session"""
        # Generate session tokens
        session_token = secrets.token_urlsafe(64)
        refresh_token = secrets.token_urlsafe(64)
        
        # Calculate expiration
        expires_at = datetime.utcnow() + timedelta(
            seconds=self.settings.security.session_timeout
        )
        
        # Create session record
        session = UserSession(
            user_id=user.id,
            session_token=session_token,
            refresh_token=refresh_token,
            ip_address=client_ip,
            user_agent=user_agent,
            expires_at=expires_at,
            status=SessionStatus.ACTIVE
        )
        
        self.db.add(session)
        self.db.commit()
        
        # Store session in Vault for fast lookup
        await self.vault.store_session(session_token, {
            'user_id': str(user.id),
            'session_id': str(session.id),
            'expires_at': expires_at.isoformat(),
            'ip_address': client_ip
        })
        
        logger.info(f"Session created for user {user.username}")
        return session
    
    async def validate_session(self, session_token: str) -> Optional[UserSession]:
        """Validate and return session if valid"""
        try:
            # Check Vault first for performance
            session_data = await self.vault.get_session(session_token)
            if not session_data:
                return None
            
            # Get session from database
            session = self.db.query(UserSession).filter(
                UserSession.session_token == session_token,
                UserSession.status == SessionStatus.ACTIVE
            ).first()
            
            if not session:
                # Clean up orphaned Vault entry
                await self.vault.delete_session(session_token)
                return None
            
            # Check expiration
            if session.expires_at <= datetime.utcnow():
                session.status = SessionStatus.EXPIRED
                self.db.commit()
                await self.vault.delete_session(session_token)
                return None
            
            # Update last activity
            session.last_activity = datetime.utcnow()
            self.db.commit()
            
            return session
            
        except Exception as e:
            logger.error(f"Session validation error: {e}")
            return None
    
    async def refresh_token(self, refresh_token: str) -> Dict[str, Any]:
        """Refresh session token"""
        try:
            # Find session by refresh token
            session = self.db.query(UserSession).filter(
                UserSession.refresh_token == refresh_token,
                UserSession.status == SessionStatus.ACTIVE
            ).first()
            
            if not session or session.expires_at <= datetime.utcnow():
                return {
                    'success': False,
                    'message': 'Invalid or expired refresh token'
                }
            
            # Generate new session token
            new_session_token = secrets.token_urlsafe(64)
            old_session_token = session.session_token
            
            # Update session
            session.session_token = new_session_token
            session.expires_at = datetime.utcnow() + timedelta(
                seconds=self.settings.security.session_timeout
            )
            session.last_activity = datetime.utcnow()
            
            self.db.commit()
            
            # Update Vault
            await self.vault.delete_session(old_session_token)
            await self.vault.store_session(new_session_token, {
                'user_id': str(session.user_id),
                'session_id': str(session.id),
                'expires_at': session.expires_at.isoformat(),
                'ip_address': session.ip_address
            })
            
            return {
                'success': True,
                'access_token': new_session_token,
                'expires_in': self.settings.security.session_timeout
            }
            
        except Exception as e:
            logger.error(f"Token refresh error: {e}")
            return {
                'success': False,
                'message': 'Token refresh failed'
            }
    
    async def logout_user(self, session_token: str) -> bool:
        """Logout user and revoke session"""
        try:
            session = self.db.query(UserSession).filter(
                UserSession.session_token == session_token
            ).first()
            
            if session:
                session.status = SessionStatus.REVOKED
                session.revoked_at = datetime.utcnow()
                self.db.commit()
                
                # Remove from Vault
                await self.vault.delete_session(session_token)
                
                logger.info(f"User session {session.id} logged out")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Logout error: {e}")
            return False
    
    async def logout_user_all_sessions(self, user_id: str) -> int:
        """Logout user from all sessions"""
        try:
            sessions = self.db.query(UserSession).filter(
                UserSession.user_id == user_id,
                UserSession.status == SessionStatus.ACTIVE
            ).all()
            
            count = 0
            for session in sessions:
                session.status = SessionStatus.REVOKED
                session.revoked_at = datetime.utcnow()
                await self.vault.delete_session(session.session_token)
                count += 1
            
            self.db.commit()
            logger.info(f"Revoked {count} sessions for user {user_id}")
            return count
            
        except Exception as e:
            logger.error(f"Logout all sessions error: {e}")
            return 0
    
    async def change_password(self, user: User, current_password: str, 
                            new_password: str) -> Dict[str, Any]:
        """Change user password"""
        try:
            # Verify current password
            if not self.security.verify_password(current_password, user.password_hash):
                return {
                    'success': False,
                    'message': 'Current password is incorrect'
                }
            
            # Validate new password
            validation_result = self.security.validate_password(new_password)
            if not validation_result['valid']:
                return {
                    'success': False,
                    'message': validation_result['message']
                }
            
            # Hash new password
            new_password_hash = self.security.hash_password(new_password)
            
            # Update user
            user.password_hash = new_password_hash
            user.updated_at = datetime.utcnow()
            
            self.db.commit()
            
            logger.info(f"Password changed for user {user.username}")
            return {
                'success': True,
                'message': 'Password changed successfully'
            }
            
        except Exception as e:
            logger.error(f"Password change error: {e}")
            return {
                'success': False,
                'message': 'Password change failed'
            }
    
    async def request_password_reset(self, email: str) -> Dict[str, Any]:
        """Request password reset"""
        try:
            user = self.db.query(User).filter(User.email == email).first()
            
            if user:
                # Generate reset token
                reset_token = secrets.token_urlsafe(32)
                expires_at = datetime.utcnow() + timedelta(hours=1)
                
                # Store reset token
                reset_record = PasswordResetToken(
                    user_id=user.id,
                    token=reset_token,
                    expires_at=expires_at
                )
                
                self.db.add(reset_record)
                self.db.commit()
                
                # Send reset email
                await self.email.send_password_reset_email(
                    user.email, 
                    user.first_name or user.username,
                    reset_token
                )
                
                logger.info(f"Password reset requested for {email}")
            
            # Always return success to prevent email enumeration
            return {
                'success': True,
                'message': 'Password reset email sent if account exists'
            }
            
        except Exception as e:
            logger.error(f"Password reset request error: {e}")
            return {
                'success': True,
                'message': 'Password reset email sent if account exists'
            }
    
    async def reset_password(self, token: str, new_password: str) -> Dict[str, Any]:
        """Reset password with token"""
        try:
            # Find valid reset token
            reset_record = self.db.query(PasswordResetToken).filter(
                PasswordResetToken.token == token,
                PasswordResetToken.used == False,
                PasswordResetToken.expires_at > datetime.utcnow()
            ).first()
            
            if not reset_record:
                return {
                    'success': False,
                    'message': 'Invalid or expired reset token'
                }
            
            # Validate new password
            validation_result = self.security.validate_password(new_password)
            if not validation_result['valid']:
                return {
                    'success': False,
                    'message': validation_result['message']
                }
            
            # Get user
            user = self.db.query(User).filter(User.id == reset_record.user_id).first()
            if not user:
                return {
                    'success': False,
                    'message': 'User not found'
                }
            
            # Update password
            user.password_hash = self.security.hash_password(new_password)
            user.updated_at = datetime.utcnow()
            
            # Mark token as used
            reset_record.used = True
            
            # Revoke all existing sessions
            await self.logout_user_all_sessions(str(user.id))
            
            self.db.commit()
            
            logger.info(f"Password reset completed for user {user.username}")
            return {
                'success': True,
                'message': 'Password reset successfully'
            }
            
        except Exception as e:
            logger.error(f"Password reset error: {e}")
            return {
                'success': False,
                'message': 'Password reset failed'
            }
    
    async def revoke_user_session(self, user: User, session_id: str) -> bool:
        """Revoke a specific user session"""
        try:
            session = self.db.query(UserSession).filter(
                UserSession.id == session_id,
                UserSession.user_id == user.id,
                UserSession.status == SessionStatus.ACTIVE
            ).first()
            
            if session:
                session.status = SessionStatus.REVOKED
                session.revoked_at = datetime.utcnow()
                self.db.commit()
                
                await self.vault.delete_session(session.session_token)
                
                logger.info(f"Session {session_id} revoked by user {user.username}")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Session revocation error: {e}")
            return False