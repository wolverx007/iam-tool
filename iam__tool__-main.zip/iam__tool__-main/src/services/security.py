"""
Security service for IAM Tool
"""
import argon2
import secrets
import re
from typing import Dict, Any
from datetime import datetime, timedelta
import logging

from config import get_settings

logger = logging.getLogger(__name__)

class SecurityService:
    def __init__(self):
        self.settings = get_settings()
        self.password_hasher = argon2.PasswordHasher(
            time_cost=3,
            memory_cost=65536,
            parallelism=1,
            hash_len=32,
            salt_len=16
        )
    
    def hash_password(self, password: str) -> str:
        """Hash password using Argon2id"""
        try:
            return self.password_hasher.hash(password)
        except Exception as e:
            logger.error(f"Password hashing error: {e}")
            raise
    
    def verify_password(self, password: str, password_hash: str) -> bool:
        """Verify password against hash"""
        try:
            self.password_hasher.verify(password_hash, password)
            return True
        except argon2.exceptions.VerifyMismatchError:
            return False
        except Exception as e:
            logger.error(f"Password verification error: {e}")
            return False
    
    def validate_password(self, password: str) -> Dict[str, Any]:
        """Validate password against security policy"""
        errors = []
        
        # Check minimum length
        if len(password) < self.settings.security.password_min_length:
            errors.append(f"Password must be at least {self.settings.security.password_min_length} characters long")
        
        # Check for uppercase letters
        if self.settings.security.password_require_uppercase and not re.search(r'[A-Z]', password):
            errors.append("Password must contain at least one uppercase letter")
        
        # Check for numbers
        if self.settings.security.password_require_numbers and not re.search(r'\d', password):
            errors.append("Password must contain at least one number")
        
        # Check for special characters
        if self.settings.security.password_require_special and not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            errors.append("Password must contain at least one special character")
        
        # Check for common patterns
        if self._is_common_password(password):
            errors.append("Password is too common or weak")
        
        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'message': '; '.join(errors) if errors else 'Password is valid'
        }
    
    def _is_common_password(self, password: str) -> bool:
        """Check if password is in common passwords list"""
        common_passwords = [
            'password', '123456', '123456789', 'qwerty', 'abc123',
            'password123', 'admin', 'letmein', 'welcome', 'monkey',
            'dragon', 'master', 'shadow', 'superman', 'michael',
            'football', 'baseball', 'liverpool', 'jordan', 'princess'
        ]
        
        return password.lower() in common_passwords
    
    def generate_secure_token(self, length: int = 32) -> str:
        """Generate cryptographically secure random token"""
        return secrets.token_urlsafe(length)
    
    def generate_session_token(self) -> str:
        """Generate session token"""
        return self.generate_secure_token(64)
    
    def generate_api_key(self) -> str:
        """Generate API key"""
        return f"iam_{self.generate_secure_token(32)}"
    
    def get_session_timeout(self) -> int:
        """Get session timeout in seconds"""
        return self.settings.security.session_timeout
    
    def is_password_expired(self, last_changed: datetime, max_age_days: int = 90) -> bool:
        """Check if password has expired"""
        if not last_changed:
            return True
        
        expiry_date = last_changed + timedelta(days=max_age_days)
        return datetime.utcnow() > expiry_date
    
    def calculate_password_strength(self, password: str) -> Dict[str, Any]:
        """Calculate password strength score"""
        score = 0
        feedback = []
        
        # Length scoring
        if len(password) >= 12:
            score += 25
        elif len(password) >= 8:
            score += 15
        else:
            feedback.append("Use at least 8 characters")
        
        # Character variety scoring
        if re.search(r'[a-z]', password):
            score += 5
        else:
            feedback.append("Add lowercase letters")
        
        if re.search(r'[A-Z]', password):
            score += 5
        else:
            feedback.append("Add uppercase letters")
        
        if re.search(r'\d', password):
            score += 5
        else:
            feedback.append("Add numbers")
        
        if re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            score += 10
        else:
            feedback.append("Add special characters")
        
        # Pattern penalties
        if re.search(r'(.)\1{2,}', password):  # Repeated characters
            score -= 10
            feedback.append("Avoid repeated characters")
        
        if re.search(r'(012|123|234|345|456|567|678|789|890)', password):  # Sequential numbers
            score -= 10
            feedback.append("Avoid sequential numbers")
        
        if re.search(r'(abc|bcd|cde|def|efg|fgh|ghi|hij|ijk|jkl|klm|lmn|mno|nop|opq|pqr|qrs|rst|stu|tuv|uvw|vwx|wxy|xyz)', password.lower()):  # Sequential letters
            score -= 10
            feedback.append("Avoid sequential letters")
        
        # Common password penalty
        if self._is_common_password(password):
            score -= 25
            feedback.append("Avoid common passwords")
        
        # Ensure score is between 0 and 100
        score = max(0, min(100, score))
        
        # Determine strength level
        if score >= 80:
            strength = "Very Strong"
            color = "green"
        elif score >= 60:
            strength = "Strong"
            color = "blue"
        elif score >= 40:
            strength = "Medium"
            color = "yellow"
        elif score >= 20:
            strength = "Weak"
            color = "orange"
        else:
            strength = "Very Weak"
            color = "red"
        
        return {
            'score': score,
            'strength': strength,
            'color': color,
            'feedback': feedback
        }
    
    def sanitize_input(self, input_string: str, max_length: int = 1000) -> str:
        """Sanitize user input"""
        if not input_string:
            return ""
        
        # Truncate to max length
        sanitized = input_string[:max_length]
        
        # Remove null bytes
        sanitized = sanitized.replace('\x00', '')
        
        # Strip whitespace
        sanitized = sanitized.strip()
        
        return sanitized
    
    def validate_email(self, email: str) -> bool:
        """Validate email format"""
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(email_pattern, email))
    
    def validate_username(self, username: str) -> Dict[str, Any]:
        """Validate username"""
        errors = []
        
        if not username:
            errors.append("Username is required")
        elif len(username) < 3:
            errors.append("Username must be at least 3 characters long")
        elif len(username) > 50:
            errors.append("Username must be less than 50 characters long")
        elif not re.match(r'^[a-zA-Z0-9_.-]+$', username):
            errors.append("Username can only contain letters, numbers, dots, hyphens, and underscores")
        elif username.startswith('.') or username.endswith('.'):
            errors.append("Username cannot start or end with a dot")
        elif '..' in username:
            errors.append("Username cannot contain consecutive dots")
        
        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'message': '; '.join(errors) if errors else 'Username is valid'
        }
    
    def generate_csrf_token(self) -> str:
        """Generate CSRF token"""
        return self.generate_secure_token(32)
    
    def constant_time_compare(self, a: str, b: str) -> bool:
        """Constant time string comparison to prevent timing attacks"""
        return secrets.compare_digest(a.encode('utf-8'), b.encode('utf-8'))