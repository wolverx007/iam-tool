"""
IAM Tool - Main FastAPI Application
"""
from fastapi import FastAPI, Depends, HTTPException, Request, Response
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
import uvicorn
import logging
import os
from pathlib import Path

from config import get_settings
from database import engine, SessionLocal
from models import Base
from routers import auth, users, projects, roles, sessions, admin, oidc
from middleware import SecurityMiddleware, AuditMiddleware
from plugins.manager import PluginManager

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Rate limiting
limiter = Limiter(key_func=get_remote_address)
security = HTTPBearer()

def create_app() -> FastAPI:
    """Create and configure the FastAPI application"""
    settings = get_settings()
    
    app = FastAPI(
        title="IAM Tool",
        description="Identity and Access Management System",
        version="1.0.0",
        docs_url="/docs",
        redoc_url="/redoc"
    )
    
    # Add rate limiting
    app.state.limiter = limiter
    app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
    
    # Add middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure this properly for production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=["*"]  # Configure this properly for production
    )
    
    app.add_middleware(SecurityMiddleware)
    app.add_middleware(AuditMiddleware)
    
    # Setup static files and templates
    static_path = Path(__file__).parent / "static"
    templates_path = Path(__file__).parent / "templates"
    
    if static_path.exists():
        app.mount("/static", StaticFiles(directory=str(static_path)), name="static")
    
    templates = Jinja2Templates(directory=str(templates_path))
    
    # Create database tables
    Base.metadata.create_all(bind=engine)
    
    # Initialize plugin manager
    plugin_manager = PluginManager(settings.plugins.directory)
    plugin_manager.load_plugins()
    
    # Include routers
    app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
    app.include_router(users.router, prefix="/api/users", tags=["Users"])
    app.include_router(projects.router, prefix="/api/projects", tags=["Projects"])
    app.include_router(roles.router, prefix="/api/roles", tags=["Roles"])
    app.include_router(sessions.router, prefix="/api/sessions", tags=["Sessions"])
    app.include_router(admin.router, prefix="/api/admin", tags=["Administration"])
    app.include_router(oidc.router, prefix="/oidc", tags=["OpenID Connect"])
    
    @app.get("/")
    async def root(request: Request):
        """Root endpoint - redirect to dashboard"""
        return templates.TemplateResponse("index.html", {"request": request})
    
    @app.get("/health")
    @limiter.limit("100/minute")
    async def health_check(request: Request):
        """Health check endpoint"""
        return {"status": "healthy", "version": "1.0.0"}
    
    @app.on_event("startup")
    async def startup_event():
        """Application startup event"""
        logger.info("IAM Tool starting up...")
        # Initialize default admin user if not exists
        # This would be implemented in the auth service
        
    @app.on_event("shutdown")
    async def shutdown_event():
        """Application shutdown event"""
        logger.info("IAM Tool shutting down...")
    
    return app

if __name__ == "__main__":
    app = create_app()
    settings = get_settings()
    
    uvicorn.run(
        app,
        host=settings.server.host,
        port=settings.server.port,
        ssl_keyfile=settings.server.ssl_key,
        ssl_certfile=settings.server.ssl_cert,
        workers=settings.server.workers,
        reload=settings.server.reload
    )