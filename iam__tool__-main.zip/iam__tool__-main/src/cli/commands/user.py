"""
User management commands for IAM CLI
"""
import click
from cli.utils.output import format_table, format_json

@click.group(name='user')
def user_group():
    """User management commands"""
    pass

@user_group.command('add')
@click.argument('role')
@click.argument('username')
@click.option('--email', required=True, help='User email address')
@click.option('--first-name', help='First name')
@click.option('--last-name', help='Last name')
@click.option('--password', help='Password (will prompt if not provided)')
@click.option('--project', help='Project name (uses current project if not specified)')
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table', help='Output format')
@click.pass_context
def add_user(ctx, role, username, email, first_name, last_name, password, project, output):
    """Add a new user to a role"""
    client = ctx.obj['client']
    
    # Prompt for password if not provided
    if not password:
        password = click.prompt('Password', hide_input=True, confirmation_prompt=True)
    
    try:
        # Get project ID if project name provided
        project_id = None
        if project:
            projects_response = client.get('/api/projects/')
            for p in projects_response.get('projects', []):
                if p['name'] == project:
                    project_id = p['id']
                    break
            
            if not project_id:
                click.echo(f"✗ Project '{project}' not found", err=True)
                return
        
        # Get role ID
        roles_response = client.get('/api/roles/', params={'project_id': project_id} if project_id else {})
        role_id = None
        for r in roles_response.get('roles', []):
            if r['name'] == role:
                role_id = r['id']
                break
        
        if not role_id:
            click.echo(f"✗ Role '{role}' not found", err=True)
            return
        
        data = {
            'username': username,
            'email': email,
            'password': password,
            'role_id': role_id
        }
        
        if first_name:
            data['first_name'] = first_name
        if last_name:
            data['last_name'] = last_name
        if project_id:
            data['project_id'] = project_id
            
        response = client.post('/api/users/', data)
        
        if output == 'json':
            click.echo(format_json(response))
        else:
            click.echo(f"✓ User '{username}' added successfully")
            click.echo(f"  ID: {response['id']}")
            click.echo(f"  Email: {response['email']}")
            click.echo(f"  Role: {role}")
        
    except Exception as e:
        click.echo(f"✗ Failed to add user: {e}", err=True)

@user_group.command('list')
@click.option('--project', help='Filter by project name')
@click.option('--role', help='Filter by role name')
@click.option('--active/--inactive', default=None, help='Filter by active status')
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table', help='Output format')
@click.pass_context
def list_users(ctx, project, role, active, output):
    """List users"""
    client = ctx.obj['client']
    
    try:
        params = {}
        
        # Get project ID if project name provided
        if project:
            projects_response = client.get('/api/projects/')
            for p in projects_response.get('projects', []):
                if p['name'] == project:
                    params['project_id'] = p['id']
                    break
            
            if 'project_id' not in params:
                click.echo(f"✗ Project '{project}' not found", err=True)
                return
        
        # Get role ID if role name provided
        if role:
            roles_response = client.get('/api/roles/', params={'project_id': params.get('project_id')})
            for r in roles_response.get('roles', []):
                if r['name'] == role:
                    params['role_id'] = r['id']
                    break
            
            if 'role_id' not in params:
                click.echo(f"✗ Role '{role}' not found", err=True)
                return
        
        if active is not None:
            params['is_active'] = active
        
        response = client.get('/api/users/', params=params)
        
        if output == 'json':
            click.echo(format_json(response))
        else:
            users = response.get('users', [])
            if not users:
                click.echo("No users found")
                return
            
            headers = ['ID', 'Username', 'Email', 'Role', 'Project', 'Active', 'Last Login']
            rows = []
            
            for user in users:
                rows.append([
                    user['id'][:8] + '...',
                    user['username'],
                    user['email'],
                    user['role']['name'] if user.get('role') else 'N/A',
                    user['project']['name'] if user.get('project') else 'N/A',
                    '✓' if user['is_active'] else '✗',
                    user['last_login'][:10] if user['last_login'] else 'Never'
                ])
            
            click.echo(format_table(headers, rows))
            click.echo(f"\nTotal: {response.get('total', len(users))} users")
        
    except Exception as e:
        click.echo(f"✗ Failed to list users: {e}", err=True)

@user_group.command('show')
@click.argument('user_id')
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table', help='Output format')
@click.pass_context
def show_user(ctx, user_id, output):
    """Show user details"""
    client = ctx.obj['client']
    
    try:
        response = client.get(f'/api/users/{user_id}')
        
        if output == 'json':
            click.echo(format_json(response))
        else:
            click.echo(f"User: {response['username']}")
            click.echo(f"  ID: {response['id']}")
            click.echo(f"  Email: {response['email']}")
            if response.get('first_name'):
                click.echo(f"  Name: {response['first_name']} {response.get('last_name', '')}")
            click.echo(f"  Role: {response['role']['name']}")
            click.echo(f"  Project: {response['project']['name']}")
            click.echo(f"  Active: {'Yes' if response['is_active'] else 'No'}")
            click.echo(f"  Verified: {'Yes' if response['is_verified'] else 'No'}")
            click.echo(f"  Created: {response['created_at']}")
            click.echo(f"  Last Login: {response['last_login'] or 'Never'}")
        
    except Exception as e:
        click.echo(f"✗ Failed to show user: {e}", err=True)

@user_group.command('update')
@click.argument('user_id')
@click.option('--email', help='New email address')
@click.option('--first-name', help='New first name')
@click.option('--last-name', help='New last name')
@click.option('--role', help='New role name')
@click.pass_context
def update_user(ctx, user_id, email, first_name, last_name, role):
    """Update user"""
    client = ctx.obj['client']
    
    if not any([email, first_name, last_name, role]):
        click.echo("Nothing to update. Specify at least one option", err=True)
        return
    
    try:
        data = {}
        
        if email:
            data['email'] = email
        if first_name:
            data['first_name'] = first_name
        if last_name:
            data['last_name'] = last_name
            
        if role:
            # Get role ID
            roles_response = client.get('/api/roles/')
            role_id = None
            for r in roles_response.get('roles', []):
                if r['name'] == role:
                    role_id = r['id']
                    break
            
            if not role_id:
                click.echo(f"✗ Role '{role}' not found", err=True)
                return
                
            data['role_id'] = role_id
            
        response = client.put(f'/api/users/{user_id}', data)
        
        click.echo(f"✓ User updated successfully")
        click.echo(f"  Username: {response['username']}")
        click.echo(f"  Email: {response['email']}")
        if response.get('role'):
            click.echo(f"  Role: {response['role']['name']}")
        
    except Exception as e:
        click.echo(f"✗ Failed to update user: {e}", err=True)

@user_group.command('delete')
@click.argument('user_id')
@click.option('--force', is_flag=True, help='Skip confirmation prompt')
@click.pass_context
def delete_user(ctx, user_id, force):
    """Delete user"""
    client = ctx.obj['client']
    
    if not force:
        if not click.confirm(f'Are you sure you want to delete user {user_id}?'):
            click.echo("Cancelled")
            return
    
    try:
        response = client.delete(f'/api/users/{user_id}')
        
        click.echo("✓ User deleted successfully")
        
    except Exception as e:
        click.echo(f"✗ Failed to delete user: {e}", err=True)

@user_group.command('activate')
@click.argument('user_id')
@click.pass_context
def activate_user(ctx, user_id):
    """Activate user account"""
    client = ctx.obj['client']
    
    try:
        response = client.post(f'/api/users/{user_id}/activate')
        
        click.echo("✓ User activated successfully")
        
    except Exception as e:
        click.echo(f"✗ Failed to activate user: {e}", err=True)

@user_group.command('deactivate')
@click.argument('user_id')
@click.pass_context
def deactivate_user(ctx, user_id):
    """Deactivate user account"""
    client = ctx.obj['client']
    
    try:
        response = client.post(f'/api/users/{user_id}/deactivate')
        
        click.echo("✓ User deactivated successfully")
        
    except Exception as e:
        click.echo(f"✗ Failed to deactivate user: {e}", err=True)

@user_group.command('unlock')
@click.argument('user_id')
@click.pass_context
def unlock_user(ctx, user_id):
    """Unlock user account"""
    client = ctx.obj['client']
    
    try:
        response = client.post(f'/api/users/{user_id}/unlock')
        
        click.echo("✓ User unlocked successfully")
        
    except Exception as e:
        click.echo(f"✗ Failed to unlock user: {e}", err=True)

@user_group.command('sessions')
@click.argument('user_id')
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table', help='Output format')
@click.pass_context
def user_sessions(ctx, user_id, output):
    """Show user sessions"""
    client = ctx.obj['client']
    
    try:
        response = client.get(f'/api/users/{user_id}/sessions')
        
        if output == 'json':
            click.echo(format_json(response))
        else:
            sessions = response.get('sessions', [])
            if not sessions:
                click.echo("No active sessions found")
                return
            
            headers = ['ID', 'IP Address', 'Created', 'Last Activity', 'Status']
            rows = []
            
            for session in sessions:
                rows.append([
                    session['id'][:8] + '...',
                    session['ip_address'],
                    session['created_at'][:16],
                    session['last_activity'][:16],
                    session['status']
                ])
            
            click.echo(format_table(headers, rows))
            click.echo(f"\nTotal: {len(sessions)} active sessions")
        
    except Exception as e:
        click.echo(f"✗ Failed to get user sessions: {e}", err=True)

@user_group.command('revoke-sessions')
@click.argument('user_id')
@click.option('--force', is_flag=True, help='Skip confirmation prompt')
@click.pass_context
def revoke_user_sessions(ctx, user_id, force):
    """Revoke all user sessions"""
    client = ctx.obj['client']
    
    if not force:
        if not click.confirm(f'Are you sure you want to revoke all sessions for user {user_id}?'):
            click.echo("Cancelled")
            return
    
    try:
        response = client.delete(f'/api/users/{user_id}/sessions')
        
        click.echo(f"✓ {response.get('message', 'Sessions revoked successfully')}")
        
    except Exception as e:
        click.echo(f"✗ Failed to revoke sessions: {e}", err=True)