"""
Role management commands for IAM CLI
"""
import click
from cli.utils.output import format_table, format_json

@click.group(name='role')
def role_group():
    """Role management commands"""
    pass

@role_group.command('create')
@click.argument('project')
@click.argument('role_name')
@click.option('--aal', type=click.Choice(['GUEST', 'AAL1', 'AAL2', 'AAL3', 'CUSTOM']), default='AAL1', help='AAL security level')
@click.option('--permissions', help='Comma-separated list of permissions')
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table', help='Output format')
@click.pass_context
def create_role(ctx, project, role_name, aal, permissions, output):
    """Create a new role"""
    client = ctx.obj['client']
    
    try:
        # Get project ID
        projects_response = client.get('/api/projects/')
        project_id = None
        for p in projects_response.get('projects', []):
            if p['name'] == project:
                project_id = p['id']
                break
        
        if not project_id:
            click.echo(f"✗ Project '{project}' not found", err=True)
            return
        
        data = {
            'name': role_name,
            'project_id': project_id,
            'aal_level': aal
        }
        
        if permissions:
            data['permissions'] = [p.strip() for p in permissions.split(',')]
            
        response = client.post('/api/roles/', data)
        
        if output == 'json':
            click.echo(format_json(response))
        else:
            click.echo(f"✓ Role '{role_name}' created successfully")
            click.echo(f"  ID: {response['id']}")
            click.echo(f"  Project: {project}")
            click.echo(f"  AAL Level: {response['aal_level']}")
        
    except Exception as e:
        click.echo(f"✗ Failed to create role: {e}", err=True)

@role_group.command('list')
@click.option('--project', help='Filter by project name')
@click.option('--active/--inactive', default=None, help='Filter by active status')
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table', help='Output format')
@click.pass_context
def list_roles(ctx, project, active, output):
    """List roles"""
    client = ctx.obj['client']
    
    try:
        params = {}
        
        # Get project ID if project name provided
        if project:
            projects_response = client.get('/api/projects/')
            for p in projects_response.get('projects', []):
                if p['name'] == project:
                    params['project_id'] = p['id']
                    break
            
            if 'project_id' not in params:
                click.echo(f"✗ Project '{project}' not found", err=True)
                return
        
        if active is not None:
            params['is_active'] = active
        
        response = client.get('/api/roles/', params=params)
        
        if output == 'json':
            click.echo(format_json(response))
        else:
            roles = response.get('roles', [])
            if not roles:
                click.echo("No roles found")
                return
            
            headers = ['ID', 'Name', 'Project', 'AAL Level', 'Permissions', 'Active', 'Created']
            rows = []
            
            for role in roles:
                permissions = ', '.join(role.get('permissions', [])) if role.get('permissions') else 'None'
                rows.append([
                    role['id'][:8] + '...',
                    role['name'],
                    role['project']['name'] if role.get('project') else 'N/A',
                    role['aal_level'],
                    permissions[:30] + '...' if len(permissions) > 30 else permissions,
                    '✓' if role['is_active'] else '✗',
                    role['created_at'][:10]
                ])
            
            click.echo(format_table(headers, rows))
            click.echo(f"\nTotal: {response.get('total', len(roles))} roles")
        
    except Exception as e:
        click.echo(f"✗ Failed to list roles: {e}", err=True)

@role_group.command('show')
@click.argument('role_id')
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table', help='Output format')
@click.pass_context
def show_role(ctx, role_id, output):
    """Show role details"""
    client = ctx.obj['client']
    
    try:
        response = client.get(f'/api/roles/{role_id}')
        
        if output == 'json':
            click.echo(format_json(response))
        else:
            click.echo(f"Role: {response['name']}")
            click.echo(f"  ID: {response['id']}")
            click.echo(f"  Project: {response['project']['name']}")
            click.echo(f"  AAL Level: {response['aal_level']}")
            click.echo(f"  Active: {'Yes' if response['is_active'] else 'No'}")
            click.echo(f"  Created: {response['created_at']}")
            click.echo(f"  Updated: {response['updated_at']}")
            
            permissions = response.get('permissions', [])
            if permissions:
                click.echo(f"  Permissions:")
                for perm in permissions:
                    click.echo(f"    - {perm}")
            else:
                click.echo(f"  Permissions: None")
        
    except Exception as e:
        click.echo(f"✗ Failed to show role: {e}", err=True)

@role_group.command('update')
@click.argument('role_id')
@click.option('--name', help='New role name')
@click.option('--aal', type=click.Choice(['GUEST', 'AAL1', 'AAL2', 'AAL3', 'CUSTOM']), help='New AAL security level')
@click.option('--permissions', help='Comma-separated list of permissions')
@click.pass_context
def update_role(ctx, role_id, name, aal, permissions):
    """Update role"""
    client = ctx.obj['client']
    
    if not any([name, aal, permissions]):
        click.echo("Nothing to update. Specify at least one option", err=True)
        return
    
    try:
        data = {}
        
        if name:
            data['name'] = name
        if aal:
            data['aal_level'] = aal
        if permissions:
            data['permissions'] = [p.strip() for p in permissions.split(',')]
            
        response = client.put(f'/api/roles/{role_id}', data)
        
        click.echo(f"✓ Role updated successfully")
        click.echo(f"  Name: {response['name']}")
        click.echo(f"  AAL Level: {response['aal_level']}")
        
    except Exception as e:
        click.echo(f"✗ Failed to update role: {e}", err=True)

@role_group.command('delete')
@click.argument('role_id')
@click.option('--force', is_flag=True, help='Skip confirmation prompt')
@click.pass_context
def delete_role(ctx, role_id, force):
    """Delete role"""
    client = ctx.obj['client']
    
    if not force:
        if not click.confirm(f'Are you sure you want to delete role {role_id}?'):
            click.echo("Cancelled")
            return
    
    try:
        response = client.delete(f'/api/roles/{role_id}')
        
        click.echo("✓ Role deleted successfully")
        
    except Exception as e:
        click.echo(f"✗ Failed to delete role: {e}", err=True)

@role_group.command('map')
@click.argument('role_id')
@click.option('--aal', type=click.Choice(['GUEST', 'AAL1', 'AAL2', 'AAL3', 'CUSTOM']), required=True, help='AAL security level to map to')
@click.pass_context
def map_role(ctx, role_id, aal):
    """Map role to AAL security level"""
    client = ctx.obj['client']
    
    try:
        response = client.post(f'/api/roles/{role_id}/map-aal', {'aal_level': aal})
        
        click.echo(f"✓ Role mapped to {aal} successfully")
        
    except Exception as e:
        click.echo(f"✗ Failed to map role: {e}", err=True)

@role_group.command('permissions')
@click.argument('role_id')
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table', help='Output format')
@click.pass_context
def show_permissions(ctx, role_id, output):
    """Show role permissions"""
    client = ctx.obj['client']
    
    try:
        response = client.get(f'/api/roles/{role_id}/permissions')
        
        if output == 'json':
            click.echo(format_json(response))
        else:
            click.echo(f"Role: {response['role_name']} ({response['aal_level']})")
            
            permissions = response.get('permissions', [])
            if permissions:
                click.echo(f"Permissions:")
                for perm in permissions:
                    click.echo(f"  - {perm}")
            else:
                click.echo(f"No permissions assigned")
        
    except Exception as e:
        click.echo(f"✗ Failed to show role permissions: {e}", err=True)

@role_group.command('set-permissions')
@click.argument('role_id')
@click.argument('permissions')
@click.pass_context
def set_permissions(ctx, role_id, permissions):
    """Set role permissions"""
    client = ctx.obj['client']
    
    try:
        perm_list = [p.strip() for p in permissions.split(',')]
        response = client.put(f'/api/roles/{role_id}/permissions', perm_list)
        
        click.echo("✓ Role permissions updated successfully")
        click.echo(f"Permissions: {', '.join(perm_list)}")
        
    except Exception as e:
        click.echo(f"✗ Failed to update role permissions: {e}", err=True)

@role_group.command('users')
@click.argument('role_id')
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table', help='Output format')
@click.pass_context
def role_users(ctx, role_id, output):
    """Show users assigned to role"""
    client = ctx.obj['client']
    
    try:
        response = client.get(f'/api/roles/{role_id}/users')
        
        if output == 'json':
            click.echo(format_json(response))
        else:
            click.echo(f"Role: {response['role_name']}")
            
            users = response.get('users', [])
            if not users:
                click.echo("No users assigned to this role")
                return
            
            headers = ['ID', 'Username', 'Email', 'Active', 'Last Login']
            rows = []
            
            for user in users:
                rows.append([
                    user['id'][:8] + '...',
                    user['username'],
                    user['email'],
                    '✓' if user['is_active'] else '✗',
                    user['last_login'][:10] if user['last_login'] else 'Never'
                ])
            
            click.echo(format_table(headers, rows))
            click.echo(f"\nTotal: {len(users)} users")
        
    except Exception as e:
        click.echo(f"✗ Failed to show role users: {e}", err=True)