"""
Project management commands for IAM CLI
"""
import click
from cli.utils.output import format_table, format_json

@click.group(name='project')
def project_group():
    """Project management commands"""
    pass

@project_group.command('create')
@click.argument('name')
@click.option('--desc', '--description', help='Project description')
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table', help='Output format')
@click.pass_context
def create_project(ctx, name, desc, output):
    """Create a new project"""
    client = ctx.obj['client']
    
    try:
        data = {'name': name}
        if desc:
            data['description'] = desc
            
        response = client.post('/api/projects/', data)
        
        if output == 'json':
            click.echo(format_json(response))
        else:
            click.echo(f"✓ Project '{name}' created successfully")
            click.echo(f"  ID: {response['id']}")
            if desc:
                click.echo(f"  Description: {desc}")
        
    except Exception as e:
        click.echo(f"✗ Failed to create project: {e}", err=True)

@project_group.command('list')
@click.option('--active/--inactive', default=True, help='Filter by active status')
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table', help='Output format')
@click.pass_context
def list_projects(ctx, active, output):
    """List all projects"""
    client = ctx.obj['client']
    
    try:
        params = {'is_active': active}
        response = client.get('/api/projects/', params=params)
        
        if output == 'json':
            click.echo(format_json(response))
        else:
            projects = response.get('projects', [])
            if not projects:
                click.echo("No projects found")
                return
            
            headers = ['ID', 'Name', 'Description', 'Active', 'Created']
            rows = []
            
            for project in projects:
                rows.append([
                    project['id'][:8] + '...',
                    project['name'],
                    project.get('description', 'N/A')[:50],
                    '✓' if project['is_active'] else '✗',
                    project['created_at'][:10]
                ])
            
            click.echo(format_table(headers, rows))
            click.echo(f"\nTotal: {response.get('total', len(projects))} projects")
        
    except Exception as e:
        click.echo(f"✗ Failed to list projects: {e}", err=True)

@project_group.command('show')
@click.argument('project_id')
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table', help='Output format')
@click.pass_context
def show_project(ctx, project_id, output):
    """Show project details"""
    client = ctx.obj['client']
    
    try:
        response = client.get(f'/api/projects/{project_id}')
        
        if output == 'json':
            click.echo(format_json(response))
        else:
            click.echo(f"Project: {response['name']}")
            click.echo(f"  ID: {response['id']}")
            click.echo(f"  Description: {response.get('description', 'N/A')}")
            click.echo(f"  Active: {'Yes' if response['is_active'] else 'No'}")
            click.echo(f"  Created: {response['created_at']}")
            click.echo(f"  Updated: {response['updated_at']}")
        
    except Exception as e:
        click.echo(f"✗ Failed to show project: {e}", err=True)

@project_group.command('update')
@click.argument('project_id')
@click.option('--name', help='New project name')
@click.option('--desc', '--description', help='New project description')
@click.pass_context
def update_project(ctx, project_id, name, desc):
    """Update project"""
    client = ctx.obj['client']
    
    if not name and not desc:
        click.echo("Nothing to update. Specify --name or --desc", err=True)
        return
    
    try:
        data = {}
        if name:
            data['name'] = name
        if desc:
            data['description'] = desc
            
        response = client.put(f'/api/projects/{project_id}', data)
        
        click.echo(f"✓ Project updated successfully")
        click.echo(f"  Name: {response['name']}")
        if response.get('description'):
            click.echo(f"  Description: {response['description']}")
        
    except Exception as e:
        click.echo(f"✗ Failed to update project: {e}", err=True)

@project_group.command('delete')
@click.argument('project_id')
@click.option('--force', is_flag=True, help='Skip confirmation prompt')
@click.pass_context
def delete_project(ctx, project_id, force):
    """Delete project"""
    client = ctx.obj['client']
    
    if not force:
        if not click.confirm(f'Are you sure you want to delete project {project_id}?'):
            click.echo("Cancelled")
            return
    
    try:
        response = client.delete(f'/api/projects/{project_id}')
        
        click.echo("✓ Project deleted successfully")
        
    except Exception as e:
        click.echo(f"✗ Failed to delete project: {e}", err=True)

@project_group.command('activate')
@click.argument('project_id')
@click.pass_context
def activate_project(ctx, project_id):
    """Activate project"""
    client = ctx.obj['client']
    
    try:
        response = client.post(f'/api/projects/{project_id}/activate')
        
        click.echo("✓ Project activated successfully")
        
    except Exception as e:
        click.echo(f"✗ Failed to activate project: {e}", err=True)

@project_group.command('deactivate')
@click.argument('project_id')
@click.pass_context
def deactivate_project(ctx, project_id):
    """Deactivate project"""
    client = ctx.obj['client']
    
    try:
        response = client.post(f'/api/projects/{project_id}/deactivate')
        
        click.echo("✓ Project deactivated successfully")
        
    except Exception as e:
        click.echo(f"✗ Failed to deactivate project: {e}", err=True)

@project_group.command('stats')
@click.argument('project_id')
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table', help='Output format')
@click.pass_context
def project_stats(ctx, project_id, output):
    """Show project statistics"""
    client = ctx.obj['client']
    
    try:
        response = client.get(f'/api/projects/{project_id}/stats')
        
        if output == 'json':
            click.echo(format_json(response))
        else:
            click.echo("Project Statistics:")
            click.echo(f"  Total Users: {response.get('total_users', 0)}")
            click.echo(f"  Active Users: {response.get('active_users', 0)}")
            click.echo(f"  Total Roles: {response.get('total_roles', 0)}")
            click.echo(f"  Active Sessions: {response.get('active_sessions', 0)}")
            click.echo(f"  Total Sites: {response.get('total_sites', 0)}")
        
    except Exception as e:
        click.echo(f"✗ Failed to get project stats: {e}", err=True)