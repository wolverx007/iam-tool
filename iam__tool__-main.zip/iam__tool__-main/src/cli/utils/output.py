"""
Output formatting utilities for IAM CLI
"""
import json
from tabulate import tabulate

def format_table(headers, rows, tablefmt='grid'):
    """Format data as a table"""
    return tabulate(rows, headers=headers, tablefmt=tablefmt)

def format_json(data, indent=2):
    """Format data as JSON"""
    return json.dumps(data, indent=indent, default=str)

def format_list(items, numbered=False):
    """Format data as a simple list"""
    output = []
    for i, item in enumerate(items, 1):
        if numbered:
            output.append(f"{i}. {item}")
        else:
            output.append(f"- {item}")
    return '\n'.join(output)

def format_key_value(data, indent=0):
    """Format data as key-value pairs"""
    output = []
    prefix = "  " * indent
    
    for key, value in data.items():
        if isinstance(value, dict):
            output.append(f"{prefix}{key}:")
            output.append(format_key_value(value, indent + 1))
        elif isinstance(value, list):
            output.append(f"{prefix}{key}:")
            for item in value:
                output.append(f"{prefix}  - {item}")
        else:
            output.append(f"{prefix}{key}: {value}")
    
    return '\n'.join(output)

def truncate_string(text, max_length=50, suffix='...'):
    """Truncate string to max length"""
    if len(text) <= max_length:
        return text
    return text[:max_length - len(suffix)] + suffix

def format_size(bytes_size):
    """Format bytes as human readable size"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_size < 1024.0:
            return f"{bytes_size:.1f} {unit}"
        bytes_size /= 1024.0
    return f"{bytes_size:.1f} PB"

def format_duration(seconds):
    """Format seconds as human readable duration"""
    if seconds < 60:
        return f"{seconds}s"
    elif seconds < 3600:
        return f"{seconds // 60}m {seconds % 60}s"
    elif seconds < 86400:
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        return f"{hours}h {minutes}m"
    else:
        days = seconds // 86400
        hours = (seconds % 86400) // 3600
        return f"{days}d {hours}h"

def colorize(text, color):
    """Colorize text for terminal output"""
    colors = {
        'red': '\033[91m',
        'green': '\033[92m',
        'yellow': '\033[93m',
        'blue': '\033[94m',
        'magenta': '\033[95m',
        'cyan': '\033[96m',
        'white': '\033[97m',
        'bold': '\033[1m',
        'end': '\033[0m'
    }
    
    return f"{colors.get(color, '')}{text}{colors.get('end', '')}"

def status_symbol(status):
    """Get status symbol"""
    symbols = {
        'active': '✓',
        'inactive': '✗',
        'pending': '⏳',
        'error': '❌',
        'warning': '⚠️',
        'info': 'ℹ️',
        'success': '✅'
    }
    
    return symbols.get(status.lower(), status)