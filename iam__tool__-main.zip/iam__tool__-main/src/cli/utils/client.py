"""
HTTP client for IAM CLI
"""
import requests
import json
from urllib.parse import urljoin
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

class IAMClient:
    def __init__(self, server_url, token=None, verify_ssl=True, timeout=30):
        self.server_url = server_url.rstrip('/')
        self.token = token
        self.timeout = timeout
        
        # Create session with retry strategy
        self.session = requests.Session()
        
        retry_strategy = Retry(
            total=3,
            status_forcelist=[429, 500, 502, 503, 504],
            method_whitelist=["HEAD", "GET", "OPTIONS"]
        )
        
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        
        # SSL verification
        self.session.verify = verify_ssl
        
        # Set default headers
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'User-Agent': 'IAM-CLI/1.0.0'
        })
        
        # Set auth token if provided
        if self.token:
            self.session.headers.update({
                'Authorization': f'Bearer {self.token}'
            })
    
    def _make_request(self, method, path, data=None, params=None, files=None):
        """Make HTTP request to IAM server"""
        url = urljoin(self.server_url, path)
        
        kwargs = {
            'timeout': self.timeout,
            'params': params
        }
        
        if files:
            # Don't set Content-Type for file uploads
            headers = self.session.headers.copy()
            if 'Content-Type' in headers:
                del headers['Content-Type']
            kwargs['headers'] = headers
            kwargs['files'] = files
        elif data is not None:
            kwargs['json'] = data
        
        try:
            response = self.session.request(method, url, **kwargs)
            
            # Handle different response types
            if response.status_code == 204:
                return {}
            
            try:
                return response.json()
            except ValueError:
                if response.status_code >= 400:
                    raise Exception(f"HTTP {response.status_code}: {response.text}")
                return response.text
                
        except requests.exceptions.ConnectionError:
            raise Exception("Failed to connect to IAM server")
        except requests.exceptions.Timeout:
            raise Exception("Request timed out")
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request failed: {e}")
    
    def get(self, path, params=None):
        """Make GET request"""
        return self._make_request('GET', path, params=params)
    
    def post(self, path, data=None, files=None):
        """Make POST request"""
        return self._make_request('POST', path, data=data, files=files)
    
    def put(self, path, data=None):
        """Make PUT request"""
        return self._make_request('PUT', path, data=data)
    
    def delete(self, path):
        """Make DELETE request"""
        return self._make_request('DELETE', path)
    
    def patch(self, path, data=None):
        """Make PATCH request"""
        return self._make_request('PATCH', path, data=data)
    
    def set_token(self, token):
        """Set authentication token"""
        self.token = token
        if token:
            self.session.headers.update({
                'Authorization': f'Bearer {token}'
            })
        else:
            self.session.headers.pop('Authorization', None)
    
    def health_check(self):
        """Check server health"""
        try:
            response = self.get('/health')
            return response.get('status') == 'healthy'
        except:
            return False