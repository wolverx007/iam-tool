#!/usr/bin/env python3
"""
IAM Control CLI Tool - Main Entry Point
"""
import click
import os
import sys
from pathlib import Path

# Add src directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from cli.commands.project import project_group
from cli.commands.user import user_group
from cli.commands.role import role_group
from cli.commands.session import session_group
from cli.commands.site import site_group
from cli.commands.config import config_group
from cli.commands.backup import backup_group
from cli.utils.client import IAMClient
from cli.utils.config import load_cli_config

@click.group()
@click.option('--config', '-c', default='/etc/iam/cli.yaml', help='Configuration file path')
@click.option('--server', '-s', help='IAM server URL')
@click.option('--token', '-t', help='Authentication token')
@click.option('--verbose', '-v', is_flag=True, help='Verbose output')
@click.pass_context
def cli(ctx, config, server, token, verbose):
    """IAM Control CLI Tool - Identity and Access Management System"""
    
    # Ensure context object exists
    ctx.ensure_object(dict)
    
    # Load CLI configuration
    cli_config = load_cli_config(config)
    
    # Override with command line options
    if server:
        cli_config['server_url'] = server
    if token:
        cli_config['token'] = token
    
    # Set verbose mode
    cli_config['verbose'] = verbose
    
    # Create IAM client
    try:
        client = IAMClient(
            server_url=cli_config.get('server_url', 'https://localhost:8443'),
            token=cli_config.get('token'),
            verify_ssl=cli_config.get('verify_ssl', False),
            timeout=cli_config.get('timeout', 30)
        )
        ctx.obj['client'] = client
        ctx.obj['config'] = cli_config
    except Exception as e:
        click.echo(f"Error: Failed to connect to IAM server: {e}", err=True)
        sys.exit(1)

# Add command groups
cli.add_command(project_group)
cli.add_command(user_group)
cli.add_command(role_group)
cli.add_command(session_group)
cli.add_command(site_group)
cli.add_command(config_group)
cli.add_command(backup_group)

@cli.command()
@click.pass_context
def version(ctx):
    """Show IAM Tool version"""
    click.echo("IAM Tool CLI v1.0.0")

@cli.command()
@click.pass_context
def status(ctx):
    """Check IAM server status"""
    client = ctx.obj['client']
    
    try:
        response = client.get('/health')
        if response.get('status') == 'healthy':
            click.echo("✓ IAM server is running and healthy")
        else:
            click.echo("⚠ IAM server is running but may have issues")
    except Exception as e:
        click.echo(f"✗ IAM server is not accessible: {e}", err=True)
        sys.exit(1)

@cli.command()
@click.option('--username', prompt=True, help='Username')
@click.option('--password', prompt=True, hide_input=True, help='Password')
@click.option('--project', prompt=True, help='Project name')
@click.pass_context
def login(ctx, username, password, project):
    """Login to IAM server"""
    client = ctx.obj['client']
    
    try:
        response = client.post('/api/auth/login', {
            'username': username,
            'password': password,
            'project': project
        })
        
        if response.get('success'):
            token = response.get('access_token')
            
            # Save token to config
            config_path = ctx.obj['config'].get('config_path', '/etc/iam/cli.yaml')
            # Update config file with token
            
            click.echo("✓ Login successful")
            click.echo(f"Token saved to {config_path}")
        else:
            click.echo(f"✗ Login failed: {response.get('message', 'Unknown error')}", err=True)
            sys.exit(1)
            
    except Exception as e:
        click.echo(f"✗ Login failed: {e}", err=True)
        sys.exit(1)

@cli.command()
@click.pass_context
def logout(ctx):
    """Logout from IAM server"""
    client = ctx.obj['client']
    
    try:
        client.post('/api/auth/logout', {})
        
        # Clear token from config
        click.echo("✓ Logout successful")
        
    except Exception as e:
        click.echo(f"Warning: Logout request failed: {e}", err=True)
        click.echo("Token cleared locally")

def main():
    """Main entry point"""
    cli()

if __name__ == '__main__':
    main()