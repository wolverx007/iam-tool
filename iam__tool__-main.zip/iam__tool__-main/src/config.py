"""
Configuration management for IAM Tool
"""
from pydantic import BaseSettings, Field
from pydantic_settings import BaseSettings
from functools import lru_cache
import os
from pathlib import Path
import yaml
from typing import List, Optional

class ServerConfig(BaseSettings):
    host: str = "0.0.0.0"
    port: int = 8443
    ssl_cert: str = "/etc/iam/ssl/server.crt"
    ssl_key: str = "/etc/iam/ssl/server.key"
    workers: int = 4
    reload: bool = False

class DatabaseConfig(BaseSettings):
    url: str = "postgresql://iam_user:password@localhost/iam_db"
    pool_size: int = 10
    max_overflow: int = 20
    pool_timeout: int = 30

class VaultConfig(BaseSettings):
    url: str = "http://127.0.0.1:8200"
    token_file: str = "/etc/iam/vault_token"
    mount_point: str = "iam_secrets"

class SecurityConfig(BaseSettings):
    secret_key: str = Field(min_length=32)
    session_timeout: int = 3600
    max_login_attempts: int = 5
    lockout_duration: int = 300
    password_min_length: int = 12
    password_require_special: bool = True
    password_require_numbers: bool = True
    password_require_uppercase: bool = True
    jwt_algorithm: str = "HS256"
    jwt_expiration: int = 3600

class AuthConfig(BaseSettings):
    default_aal: str = "AAL1"
    allow_registration: bool = False
    require_email_verification: bool = True
    totp_issuer: str = "IAM Tool"

class PluginConfig(BaseSettings):
    enabled: List[str] = ["totp", "webauthn", "email"]
    directory: str = "/opt/iam/plugins"

class LoggingConfig(BaseSettings):
    level: str = "INFO"
    file: str = "/var/log/iam/app.log"
    max_bytes: int = 10485760
    backup_count: int = 5
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

class RedisConfig(BaseSettings):
    url: str = "redis://localhost:6379/0"

class EmailConfig(BaseSettings):
    smtp_host: str = "localhost"
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    from_email: str = "noreply@iam.local"

class BackupConfig(BaseSettings):
    directory: str = "/var/backups/iam"
    retention_days: int = 30

class Settings(BaseSettings):
    server: ServerConfig = ServerConfig()
    database: DatabaseConfig = DatabaseConfig()
    vault: VaultConfig = VaultConfig()
    security: SecurityConfig = SecurityConfig()
    authentication: AuthConfig = AuthConfig()
    plugins: PluginConfig = PluginConfig()
    logging: LoggingConfig = LoggingConfig()
    redis: RedisConfig = RedisConfig()
    email: EmailConfig = EmailConfig()
    backup: BackupConfig = BackupConfig()
    
    class Config:
        env_file = "/etc/iam/.env"
        env_nested_delimiter = "__"

def load_config_from_yaml(config_file: str = "/etc/iam/config.yaml") -> dict:
    """Load configuration from YAML file"""
    config_path = Path(config_file)
    if config_path.exists():
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    return {}

@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance"""
    # Load from YAML first, then override with environment variables
    yaml_config = load_config_from_yaml()
    
    # Create settings with YAML config as base
    if yaml_config:
        return Settings(**yaml_config)
    else:
        return Settings()

# Export settings for easy import
settings = get_settings()