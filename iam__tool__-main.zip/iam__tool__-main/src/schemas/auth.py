"""
Authentication schemas for IAM Tool
"""
from pydantic import BaseModel, EmailStr
from typing import Optional, List

class LoginRequest(BaseModel):
    username: str
    password: str
    project: str

class LoginResponse(BaseModel):
    success: bool
    access_token: Optional[str] = None
    refresh_token: Optional[str] = None
    expires_in: Optional[int] = None
    user_id: Optional[str] = None
    username: Optional[str] = None
    role: Optional[str] = None
    aal_level: Optional[str] = None
    requires_mfa: bool = False
    mfa_methods: List[str] = []
    temp_token: Optional[str] = None
    message: str = ""

class RegisterRequest(BaseModel):
    username: str
    email: EmailStr
    password: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    project: str

class TotpVerificationRequest(BaseModel):
    temp_token: str
    totp_code: str

class WebAuthnVerificationRequest(BaseModel):
    temp_token: str
    credential_response: dict

class PasswordChangeRequest(BaseModel):
    current_password: str
    new_password: str

class PasswordResetRequest(BaseModel):
    email: EmailStr

class PasswordResetConfirmRequest(BaseModel):
    token: str
    new_password: str

class RefreshTokenRequest(BaseModel):
    refresh_token: str

class LogoutRequest(BaseModel):
    all_sessions: bool = False