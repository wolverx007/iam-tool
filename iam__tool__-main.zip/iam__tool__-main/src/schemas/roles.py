"""
Role schemas for IAM Tool
"""
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from models import AALLevel

class RoleBase(BaseModel):
    name: str
    aal_level: AALLevel = AALLevel.AAL1
    permissions: List[str] = []

class RoleCreate(RoleBase):
    project_id: str

class RoleUpdate(BaseModel):
    name: Optional[str] = None
    aal_level: Optional[AALLevel] = None
    permissions: Optional[List[str]] = None
    is_active: Optional[bool] = None

class RoleResponse(RoleBase):
    id: str
    project_id: str
    is_active: bool
    created_at: datetime
    updated_at: datetime
    project: dict
    
    class Config:
        from_attributes = True

class RoleListResponse(BaseModel):
    roles: List[RoleResponse]
    total: int
    skip: int
    limit: int