"""
Role management router for IAM Tool
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
import logging

from database import get_db
from models import User, Role, AALLevel
from schemas.roles import RoleCreate, RoleUpdate, RoleResponse, RoleListResponse
from services.role import RoleService
from dependencies import get_current_user, require_permission

router = APIRouter()
logger = logging.getLogger(__name__)

@router.post("/", response_model=RoleResponse)
async def create_role(
    role_data: RoleCreate,
    current_user: User = Depends(require_permission("create_role")),
    db: Session = Depends(get_db)
):
    """Create a new role"""
    try:
        role_service = RoleService(db)
        
        # Check if user can create roles in the specified project
        if role_data.project_id != str(current_user.project_id):
            # Only admins can create roles in other projects
            if current_user.role.name != "admin":
                raise HTTPException(
                    status_code=403,
                    detail="Insufficient permissions to create role in this project"
                )
        
        role = await role_service.create_role(role_data)
        
        return RoleResponse.from_orm(role)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Role creation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to create role")

@router.get("/", response_model=RoleListResponse)
async def list_roles(
    project_id: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(True),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List roles with filtering"""
    try:
        role_service = RoleService(db)
        
        # Filter by project if user is not admin
        if current_user.role.name != "admin" and not project_id:
            project_id = str(current_user.project_id)
        
        roles, total = await role_service.list_roles(
            project_id=project_id,
            is_active=is_active,
            skip=skip,
            limit=limit
        )
        
        return RoleListResponse(
            roles=[RoleResponse.from_orm(role) for role in roles],
            total=total,
            skip=skip,
            limit=limit
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Role listing error: {e}")
        raise HTTPException(status_code=500, detail="Failed to list roles")

@router.get("/{role_id}", response_model=RoleResponse)
async def get_role(
    role_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get role by ID"""
    try:
        role_service = RoleService(db)
        
        role = await role_service.get_role_by_id(role_id)
        
        if not role:
            raise HTTPException(status_code=404, detail="Role not found")
        
        # Check if user can access this role
        if (role.project_id != current_user.project_id and 
            current_user.role.name != "admin"):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to access this role"
            )
        
        return RoleResponse.from_orm(role)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Role retrieval error: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve role")

@router.put("/{role_id}", response_model=RoleResponse)
async def update_role(
    role_id: str,
    role_data: RoleUpdate,
    current_user: User = Depends(require_permission("update_role")),
    db: Session = Depends(get_db)
):
    """Update role"""
    try:
        role_service = RoleService(db)
        
        # Get existing role
        existing_role = await role_service.get_role_by_id(role_id)
        
        if not existing_role:
            raise HTTPException(status_code=404, detail="Role not found")
        
        # Check permissions
        if (existing_role.project_id != current_user.project_id and 
            current_user.role.name != "admin"):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to update this role"
            )
        
        role = await role_service.update_role(role_id, role_data)
        
        return RoleResponse.from_orm(role)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Role update error: {e}")
        raise HTTPException(status_code=500, detail="Failed to update role")

@router.delete("/{role_id}")
async def delete_role(
    role_id: str,
    current_user: User = Depends(require_permission("delete_role")),
    db: Session = Depends(get_db)
):
    """Delete role (soft delete)"""
    try:
        role_service = RoleService(db)
        
        # Get existing role
        existing_role = await role_service.get_role_by_id(role_id)
        
        if not existing_role:
            raise HTTPException(status_code=404, detail="Role not found")
        
        # Check permissions
        if (existing_role.project_id != current_user.project_id and 
            current_user.role.name != "admin"):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to delete this role"
            )
        
        # Check if role is in use
        if await role_service.is_role_in_use(role_id):
            raise HTTPException(
                status_code=400,
                detail="Cannot delete role that is assigned to users"
            )
        
        success = await role_service.delete_role(role_id)
        
        if not success:
            raise HTTPException(status_code=404, detail="Role not found")
        
        return {"success": True, "message": "Role deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Role deletion error: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete role")

@router.get("/{role_id}/permissions")
async def get_role_permissions(
    role_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get role permissions"""
    try:
        role_service = RoleService(db)
        
        role = await role_service.get_role_by_id(role_id)
        
        if not role:
            raise HTTPException(status_code=404, detail="Role not found")
        
        # Check permissions
        if (role.project_id != current_user.project_id and 
            current_user.role.name != "admin"):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to view role permissions"
            )
        
        return {
            "role_id": str(role.id),
            "role_name": role.name,
            "permissions": role.permissions,
            "aal_level": role.aal_level.value
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Role permissions error: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve role permissions")

@router.put("/{role_id}/permissions")
async def update_role_permissions(
    role_id: str,
    permissions: List[str],
    current_user: User = Depends(require_permission("update_role")),
    db: Session = Depends(get_db)
):
    """Update role permissions"""
    try:
        role_service = RoleService(db)
        
        # Get existing role
        existing_role = await role_service.get_role_by_id(role_id)
        
        if not existing_role:
            raise HTTPException(status_code=404, detail="Role not found")
        
        # Check permissions
        if (existing_role.project_id != current_user.project_id and 
            current_user.role.name != "admin"):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to update role permissions"
            )
        
        success = await role_service.update_role_permissions(role_id, permissions)
        
        if not success:
            raise HTTPException(status_code=404, detail="Role not found")
        
        return {"success": True, "message": "Role permissions updated successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Role permissions update error: {e}")
        raise HTTPException(status_code=500, detail="Failed to update role permissions")

@router.post("/{role_id}/map-aal")
async def map_role_to_aal(
    role_id: str,
    aal_level: AALLevel,
    current_user: User = Depends(require_permission("update_role")),
    db: Session = Depends(get_db)
):
    """Map role to AAL security level"""
    try:
        role_service = RoleService(db)
        
        # Get existing role
        existing_role = await role_service.get_role_by_id(role_id)
        
        if not existing_role:
            raise HTTPException(status_code=404, detail="Role not found")
        
        # Check permissions
        if (existing_role.project_id != current_user.project_id and 
            current_user.role.name != "admin"):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to map role AAL level"
            )
        
        success = await role_service.map_role_to_aal(role_id, aal_level)
        
        if not success:
            raise HTTPException(status_code=404, detail="Role not found")
        
        return {
            "success": True,
            "message": f"Role mapped to {aal_level.value} successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Role AAL mapping error: {e}")
        raise HTTPException(status_code=500, detail="Failed to map role to AAL level")

@router.get("/{role_id}/users")
async def get_role_users(
    role_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get users assigned to role"""
    try:
        role_service = RoleService(db)
        
        role = await role_service.get_role_by_id(role_id)
        
        if not role:
            raise HTTPException(status_code=404, detail="Role not found")
        
        # Check permissions
        if (role.project_id != current_user.project_id and 
            current_user.role.name != "admin"):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to view role users"
            )
        
        users = await role_service.get_role_users(role_id)
        
        return {
            "role_id": str(role.id),
            "role_name": role.name,
            "users": [
                {
                    "id": str(user.id),
                    "username": user.username,
                    "email": user.email,
                    "is_active": user.is_active,
                    "last_login": user.last_login.isoformat() if user.last_login else None
                }
                for user in users
            ]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Role users error: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve role users")