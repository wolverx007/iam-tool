"""
User management router for IAM Tool
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
import logging

from database import get_db
from models import User, Role, Project
from schemas.users import UserCreate, UserUpdate, UserResponse, UserListResponse
from services.user import UserService
from dependencies import get_current_user, require_aal, require_permission
from models import AALLevel

router = APIRouter()
logger = logging.getLogger(__name__)

@router.post("/", response_model=UserResponse)
async def create_user(
    user_data: UserCreate,
    current_user: User = Depends(require_permission("create_user")),
    db: Session = Depends(get_db)
):
    """Create a new user"""
    try:
        user_service = UserService(db)
        
        # Check if user can create users in the specified project
        if user_data.project_id != current_user.project_id:
            # Only admins can create users in other projects
            if current_user.role.name != "admin":
                raise HTTPException(
                    status_code=403,
                    detail="Insufficient permissions to create user in this project"
                )
        
        user = await user_service.create_user(user_data)
        
        return UserResponse.from_orm(user)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"User creation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to create user")

@router.get("/", response_model=UserListResponse)
async def list_users(
    project_id: Optional[str] = Query(None),
    role_id: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(True),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    current_user: User = Depends(require_permission("read_user")),
    db: Session = Depends(get_db)
):
    """List users with filtering"""
    try:
        user_service = UserService(db)
        
        # Filter by project if user is not admin
        if current_user.role.name != "admin" and not project_id:
            project_id = str(current_user.project_id)
        
        users, total = await user_service.list_users(
            project_id=project_id,
            role_id=role_id,
            is_active=is_active,
            skip=skip,
            limit=limit
        )
        
        return UserListResponse(
            users=[UserResponse.from_orm(user) for user in users],
            total=total,
            skip=skip,
            limit=limit
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"User listing error: {e}")
        raise HTTPException(status_code=500, detail="Failed to list users")

@router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: str,
    current_user: User = Depends(require_permission("read_user")),
    db: Session = Depends(get_db)
):
    """Get user by ID"""
    try:
        user_service = UserService(db)
        
        user = await user_service.get_user_by_id(user_id)
        
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Check if user can access this user's information
        if (user.project_id != current_user.project_id and 
            current_user.role.name != "admin"):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to access this user"
            )
        
        return UserResponse.from_orm(user)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"User retrieval error: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve user")

@router.put("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: str,
    user_data: UserUpdate,
    current_user: User = Depends(require_permission("update_user")),
    db: Session = Depends(get_db)
):
    """Update user"""
    try:
        user_service = UserService(db)
        
        # Get existing user
        existing_user = await user_service.get_user_by_id(user_id)
        
        if not existing_user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Check permissions
        if (existing_user.project_id != current_user.project_id and 
            current_user.role.name != "admin"):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to update this user"
            )
        
        user = await user_service.update_user(user_id, user_data)
        
        return UserResponse.from_orm(user)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"User update error: {e}")
        raise HTTPException(status_code=500, detail="Failed to update user")

@router.delete("/{user_id}")
async def delete_user(
    user_id: str,
    current_user: User = Depends(require_permission("delete_user")),
    db: Session = Depends(get_db)
):
    """Delete user (soft delete)"""
    try:
        user_service = UserService(db)
        
        # Get existing user
        existing_user = await user_service.get_user_by_id(user_id)
        
        if not existing_user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Check permissions
        if (existing_user.project_id != current_user.project_id and 
            current_user.role.name != "admin"):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to delete this user"
            )
        
        # Prevent self-deletion
        if existing_user.id == current_user.id:
            raise HTTPException(
                status_code=400,
                detail="Cannot delete your own account"
            )
        
        success = await user_service.delete_user(user_id)
        
        if not success:
            raise HTTPException(status_code=404, detail="User not found")
        
        return {"success": True, "message": "User deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"User deletion error: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete user")

@router.post("/{user_id}/activate")
async def activate_user(
    user_id: str,
    current_user: User = Depends(require_permission("update_user")),
    db: Session = Depends(get_db)
):
    """Activate user account"""
    try:
        user_service = UserService(db)
        
        success = await user_service.activate_user(user_id)
        
        if not success:
            raise HTTPException(status_code=404, detail="User not found")
        
        return {"success": True, "message": "User activated successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"User activation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to activate user")

@router.post("/{user_id}/deactivate")
async def deactivate_user(
    user_id: str,
    current_user: User = Depends(require_permission("update_user")),
    db: Session = Depends(get_db)
):
    """Deactivate user account"""
    try:
        user_service = UserService(db)
        
        # Prevent self-deactivation
        if user_id == str(current_user.id):
            raise HTTPException(
                status_code=400,
                detail="Cannot deactivate your own account"
            )
        
        success = await user_service.deactivate_user(user_id)
        
        if not success:
            raise HTTPException(status_code=404, detail="User not found")
        
        return {"success": True, "message": "User deactivated successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"User deactivation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to deactivate user")

@router.post("/{user_id}/unlock")
async def unlock_user(
    user_id: str,
    current_user: User = Depends(require_permission("update_user")),
    db: Session = Depends(get_db)
):
    """Unlock user account"""
    try:
        user_service = UserService(db)
        
        success = await user_service.unlock_user(user_id)
        
        if not success:
            raise HTTPException(status_code=404, detail="User not found")
        
        return {"success": True, "message": "User unlocked successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"User unlock error: {e}")
        raise HTTPException(status_code=500, detail="Failed to unlock user")

@router.get("/{user_id}/sessions")
async def get_user_sessions(
    user_id: str,
    current_user: User = Depends(require_permission("read_session")),
    db: Session = Depends(get_db)
):
    """Get user's active sessions"""
    try:
        user_service = UserService(db)
        
        # Check permissions
        if (user_id != str(current_user.id) and 
            current_user.role.name not in ["admin", "manager"]):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to view sessions"
            )
        
        sessions = await user_service.get_user_sessions(user_id)
        
        return {
            "sessions": [
                {
                    "id": str(session.id),
                    "ip_address": session.ip_address,
                    "user_agent": session.user_agent,
                    "created_at": session.created_at.isoformat(),
                    "last_activity": session.last_activity.isoformat(),
                    "expires_at": session.expires_at.isoformat(),
                    "status": session.status.value
                }
                for session in sessions
            ]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Session retrieval error: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve sessions")

@router.delete("/{user_id}/sessions")
async def revoke_all_user_sessions(
    user_id: str,
    current_user: User = Depends(require_permission("update_session")),
    db: Session = Depends(get_db)
):
    """Revoke all user sessions"""
    try:
        user_service = UserService(db)
        
        # Check permissions
        if (user_id != str(current_user.id) and 
            current_user.role.name not in ["admin", "manager"]):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to revoke sessions"
            )
        
        count = await user_service.revoke_all_user_sessions(user_id)
        
        return {
            "success": True,
            "message": f"Revoked {count} sessions successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Session revocation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to revoke sessions")