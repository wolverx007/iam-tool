"""
OpenID Connect (OIDC) router for IAM Tool
"""
from fastapi import APIRouter, Depends, HTTPException, Request, Form, Query
from fastapi.responses import RedirectResponse, JSONResponse
from sqlalchemy.orm import Session
from urllib.parse import urlencode, parse_qs, urlparse
import logging

from database import get_db
from models import User, Site, OIDCAuthorizationCode
from services.oidc import OIDCService
from services.auth import AuthService
from dependencies import get_current_user
from config import get_settings

router = APIRouter()
logger = logging.getLogger(__name__)

@router.get("/.well-known/openid_configuration")
async def openid_configuration(request: Request):
    """OpenID Connect discovery document"""
    settings = get_settings()
    base_url = f"https://{request.url.hostname}:{settings.server.port}"
    
    config = {
        "issuer": base_url,
        "authorization_endpoint": f"{base_url}/oidc/auth",
        "token_endpoint": f"{base_url}/oidc/token",
        "userinfo_endpoint": f"{base_url}/oidc/userinfo",
        "jwks_uri": f"{base_url}/oidc/jwks",
        "response_types_supported": ["code", "id_token", "code id_token"],
        "subject_types_supported": ["public"],
        "id_token_signing_alg_values_supported": ["RS256"],
        "scopes_supported": ["openid", "profile", "email"],
        "token_endpoint_auth_methods_supported": ["client_secret_post", "client_secret_basic"],
        "claims_supported": [
            "iss", "sub", "aud", "exp", "iat", "auth_time",
            "name", "given_name", "family_name", "email", "email_verified"
        ],
        "grant_types_supported": ["authorization_code", "refresh_token"],
        "code_challenge_methods_supported": ["S256"]
    }
    
    return JSONResponse(config)

@router.get("/auth")
async def authorization_endpoint(
    request: Request,
    response_type: str = Query(...),
    client_id: str = Query(...),
    redirect_uri: str = Query(...),
    scope: str = Query("openid"),
    state: str = Query(None),
    code_challenge: str = Query(None),
    code_challenge_method: str = Query(None),
    db: Session = Depends(get_db)
):
    """OIDC Authorization endpoint"""
    try:
        oidc_service = OIDCService(db)
        
        # Validate client
        client = await oidc_service.get_client_by_id(client_id)
        if not client:
            raise HTTPException(status_code=400, detail="Invalid client_id")
        
        # Validate redirect URI
        if redirect_uri not in client.callback_urls:
            raise HTTPException(status_code=400, detail="Invalid redirect_uri")
        
        # Validate response type
        if response_type not in client.response_types:
            raise HTTPException(status_code=400, detail="Unsupported response_type")
        
        # Check if user is authenticated
        auth_header = request.headers.get("Authorization")
        current_user = None
        
        if auth_header:
            try:
                auth_service = AuthService(db)
                token = auth_header.replace("Bearer ", "")
                session = await auth_service.validate_session(token)
                if session and session.status == "ACTIVE":
                    current_user = session.user
            except:
                pass
        
        # If not authenticated, redirect to login
        if not current_user:
            login_url = f"/login?{urlencode({
                'client_id': client_id,
                'redirect_uri': redirect_uri,
                'response_type': response_type,
                'scope': scope,
                'state': state or '',
                'code_challenge': code_challenge or '',
                'code_challenge_method': code_challenge_method or ''
            })}"
            return RedirectResponse(login_url)
        
        # Generate authorization code
        auth_code = await oidc_service.create_authorization_code(
            user=current_user,
            client=client,
            scopes=scope.split(),
            redirect_uri=redirect_uri,
            state=state,
            code_challenge=code_challenge,
            code_challenge_method=code_challenge_method
        )
        
        # Redirect with authorization code
        callback_params = {
            'code': auth_code.code,
            'state': state
        } if state else {'code': auth_code.code}
        
        callback_url = f"{redirect_uri}?{urlencode(callback_params)}"
        return RedirectResponse(callback_url)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"OIDC authorization error: {e}")
        
        # Redirect with error
        error_params = {
            'error': 'server_error',
            'error_description': 'Internal server error',
            'state': state
        } if state else {
            'error': 'server_error',
            'error_description': 'Internal server error'
        }
        
        error_url = f"{redirect_uri}?{urlencode(error_params)}"
        return RedirectResponse(error_url)

@router.post("/token")
async def token_endpoint(
    grant_type: str = Form(...),
    code: str = Form(None),
    redirect_uri: str = Form(None),
    client_id: str = Form(...),
    client_secret: str = Form(...),
    code_verifier: str = Form(None),
    refresh_token: str = Form(None),
    db: Session = Depends(get_db)
):
    """OIDC Token endpoint"""
    try:
        oidc_service = OIDCService(db)
        
        # Validate client
        client = await oidc_service.validate_client(client_id, client_secret)
        if not client:
            raise HTTPException(status_code=401, detail="Invalid client credentials")
        
        if grant_type == "authorization_code":
            if not code or not redirect_uri:
                raise HTTPException(status_code=400, detail="Missing required parameters")
            
            # Exchange authorization code for tokens
            tokens = await oidc_service.exchange_code_for_tokens(
                code=code,
                client=client,
                redirect_uri=redirect_uri,
                code_verifier=code_verifier
            )
            
            return tokens
            
        elif grant_type == "refresh_token":
            if not refresh_token:
                raise HTTPException(status_code=400, detail="Missing refresh_token")
            
            # Refresh tokens
            tokens = await oidc_service.refresh_tokens(
                refresh_token=refresh_token,
                client=client
            )
            
            return tokens
            
        else:
            raise HTTPException(status_code=400, detail="Unsupported grant_type")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"OIDC token error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/userinfo")
async def userinfo_endpoint(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """OIDC UserInfo endpoint"""
    try:
        oidc_service = OIDCService(db)
        
        userinfo = await oidc_service.get_userinfo(current_user)
        
        return userinfo
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"OIDC userinfo error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/jwks")
async def jwks_endpoint():
    """OIDC JSON Web Key Set endpoint"""
    try:
        oidc_service = OIDCService(None)
        
        jwks = await oidc_service.get_jwks()
        
        return jwks
        
    except Exception as e:
        logger.error(f"OIDC JWKS error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/logout")
async def logout_endpoint(
    post_logout_redirect_uri: str = Form(None),
    state: str = Form(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """OIDC Logout endpoint"""
    try:
        auth_service = AuthService(db)
        
        # Logout user
        await auth_service.logout_user_all_sessions(current_user.id)
        
        # Redirect to post-logout URI if provided
        if post_logout_redirect_uri:
            redirect_params = {'state': state} if state else {}
            logout_url = f"{post_logout_redirect_uri}?{urlencode(redirect_params)}" if redirect_params else post_logout_redirect_uri
            return RedirectResponse(logout_url)
        
        return {"message": "Logged out successfully"}
        
    except Exception as e:
        logger.error(f"OIDC logout error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/clients")
async def list_clients(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List OIDC clients (admin only)"""
    try:
        if current_user.role.name != "admin":
            raise HTTPException(status_code=403, detail="Admin access required")
        
        oidc_service = OIDCService(db)
        
        clients = await oidc_service.list_clients()
        
        return {
            "clients": [
                {
                    "id": str(client.id),
                    "name": client.name,
                    "client_id": client.client_id,
                    "url": client.url,
                    "callback_urls": client.callback_urls,
                    "scopes": client.scopes,
                    "is_active": client.is_active,
                    "created_at": client.created_at.isoformat()
                }
                for client in clients
            ]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"OIDC client listing error: {e}")
        raise HTTPException(status_code=500, detail="Failed to list clients")

@router.post("/clients")
async def create_client(
    name: str = Form(...),
    url: str = Form(...),
    callback_urls: str = Form(...),  # JSON string
    scopes: str = Form("openid profile email"),
    project_id: str = Form(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create OIDC client"""
    try:
        if current_user.role.name not in ["admin", "manager"]:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        oidc_service = OIDCService(db)
        
        import json
        callback_urls_list = json.loads(callback_urls)
        scopes_list = scopes.split()
        
        client = await oidc_service.create_client(
            name=name,
            url=url,
            callback_urls=callback_urls_list,
            scopes=scopes_list,
            project_id=project_id
        )
        
        return {
            "success": True,
            "client_id": client.client_id,
            "client_secret": client.client_secret,
            "message": "Client created successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"OIDC client creation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to create client")

@router.delete("/clients/{client_id}")
async def delete_client(
    client_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete OIDC client"""
    try:
        if current_user.role.name not in ["admin", "manager"]:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        oidc_service = OIDCService(db)
        
        success = await oidc_service.delete_client(client_id)
        
        if not success:
            raise HTTPException(status_code=404, detail="Client not found")
        
        return {"success": True, "message": "Client deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"OIDC client deletion error: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete client")