"""
Admin dashboard router for IAM Tool
"""
from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile, File
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
from pathlib import Path
import logging
import shutil

from database import get_db
from models import User
from services.admin import AdminService
from dependencies import get_current_user, require_admin
from config import get_settings

router = APIRouter()
logger = logging.getLogger(__name__)
templates_path = Path(__file__).parent.parent / "templates"
templates = Jinja2Templates(directory=str(templates_path))

@router.get("/dashboard", response_class=HTMLResponse)
async def admin_dashboard(
    request: Request,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """Admin dashboard page"""
    try:
        admin_service = AdminService(db)
        
        # Get dashboard statistics
        stats = await admin_service.get_dashboard_stats()
        
        return templates.TemplateResponse(
            "admin/dashboard.html",
            {
                "request": request,
                "user": current_user,
                "stats": stats
            }
        )
        
    except Exception as e:
        logger.error(f"Admin dashboard error: {e}")
        raise HTTPException(status_code=500, detail="Failed to load dashboard")

@router.get("/stats")
async def get_system_stats(
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """Get system statistics"""
    try:
        admin_service = AdminService(db)
        
        stats = await admin_service.get_system_stats()
        
        return stats
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"System stats error: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve system stats")

@router.get("/health")
async def system_health_check(
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """System health check"""
    try:
        admin_service = AdminService(db)
        
        health = await admin_service.health_check()
        
        return health
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Health check error: {e}")
        raise HTTPException(status_code=500, detail="Health check failed")

@router.get("/audit-logs")
async def get_audit_logs(
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """Get audit logs"""
    try:
        admin_service = AdminService(db)
        
        logs, total = await admin_service.get_audit_logs(skip=skip, limit=limit)
        
        return {
            "logs": [
                {
                    "id": str(log.id),
                    "user_id": str(log.user_id) if log.user_id else None,
                    "project_id": str(log.project_id) if log.project_id else None,
                    "action": log.action.value,
                    "resource_type": log.resource_type,
                    "resource_id": log.resource_id,
                    "details": log.details,
                    "ip_address": log.ip_address,
                    "user_agent": log.user_agent,
                    "timestamp": log.timestamp.isoformat(),
                    "success": log.success,
                    "error_message": log.error_message
                }
                for log in logs
            ],
            "total": total,
            "skip": skip,
            "limit": limit
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Audit logs error: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve audit logs")

@router.post("/backup")
async def create_backup(
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """Create system backup"""
    try:
        admin_service = AdminService(db)
        
        backup_path = await admin_service.create_backup()
        
        return {
            "success": True,
            "message": "Backup created successfully",
            "backup_path": backup_path
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Backup creation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to create backup")

@router.get("/backups")
async def list_backups(
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """List available backups"""
    try:
        admin_service = AdminService(db)
        
        backups = await admin_service.list_backups()
        
        return {"backups": backups}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Backup listing error: {e}")
        raise HTTPException(status_code=500, detail="Failed to list backups")

@router.post("/restore")
async def restore_backup(
    backup_path: str,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """Restore from backup"""
    try:
        admin_service = AdminService(db)
        
        success = await admin_service.restore_backup(backup_path)
        
        if not success:
            raise HTTPException(status_code=400, detail="Backup restore failed")
        
        return {
            "success": True,
            "message": "Backup restored successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Backup restore error: {e}")
        raise HTTPException(status_code=500, detail="Failed to restore backup")

@router.get("/config")
async def get_system_config(
    current_user: User = Depends(require_admin)
):
    """Get system configuration (sanitized)"""
    try:
        settings = get_settings()
        
        # Return sanitized config without secrets
        config = {
            "server": {
                "host": settings.server.host,
                "port": settings.server.port,
                "workers": settings.server.workers
            },
            "security": {
                "session_timeout": settings.security.session_timeout,
                "max_login_attempts": settings.security.max_login_attempts,
                "lockout_duration": settings.security.lockout_duration,
                "password_min_length": settings.security.password_min_length,
                "password_require_special": settings.security.password_require_special,
                "password_require_numbers": settings.security.password_require_numbers,
                "password_require_uppercase": settings.security.password_require_uppercase
            },
            "authentication": {
                "default_aal": settings.authentication.default_aal,
                "allow_registration": settings.authentication.allow_registration,
                "require_email_verification": settings.authentication.require_email_verification,
                "totp_issuer": settings.authentication.totp_issuer
            },
            "plugins": {
                "enabled": settings.plugins.enabled
            }
        }
        
        return config
        
    except Exception as e:
        logger.error(f"Config retrieval error: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve configuration")

@router.post("/upload-login-template")
async def upload_login_template(
    file: UploadFile = File(...),
    current_user: User = Depends(require_admin)
):
    """Upload custom login template"""
    try:
        if not file.filename.endswith('.html'):
            raise HTTPException(
                status_code=400,
                detail="Only HTML files are allowed"
            )
        
        # Save uploaded file
        upload_path = Path("/opt/iam/templates/custom")
        upload_path.mkdir(exist_ok=True)
        
        file_path = upload_path / "login.html"
        
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        return {
            "success": True,
            "message": "Login template uploaded successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Template upload error: {e}")
        raise HTTPException(status_code=500, detail="Failed to upload template")

@router.delete("/custom-login-template")
async def delete_custom_login_template(
    current_user: User = Depends(require_admin)
):
    """Delete custom login template"""
    try:
        template_path = Path("/opt/iam/templates/custom/login.html")
        
        if template_path.exists():
            template_path.unlink()
        
        return {
            "success": True,
            "message": "Custom login template deleted successfully"
        }
        
    except Exception as e:
        logger.error(f"Template deletion error: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete template")

@router.post("/maintenance-mode")
async def enable_maintenance_mode(
    message: str = "System is under maintenance",
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """Enable maintenance mode"""
    try:
        admin_service = AdminService(db)
        
        await admin_service.enable_maintenance_mode(message)
        
        return {
            "success": True,
            "message": "Maintenance mode enabled"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Maintenance mode error: {e}")
        raise HTTPException(status_code=500, detail="Failed to enable maintenance mode")

@router.delete("/maintenance-mode")
async def disable_maintenance_mode(
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """Disable maintenance mode"""
    try:
        admin_service = AdminService(db)
        
        await admin_service.disable_maintenance_mode()
        
        return {
            "success": True,
            "message": "Maintenance mode disabled"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Maintenance mode error: {e}")
        raise HTTPException(status_code=500, detail="Failed to disable maintenance mode")

@router.get("/system-info")
async def get_system_info(
    current_user: User = Depends(require_admin)
):
    """Get system information"""
    try:
        import platform
        import psutil
        from datetime import datetime
        
        system_info = {
            "platform": platform.platform(),
            "python_version": platform.python_version(),
            "cpu_count": psutil.cpu_count(),
            "memory_total": psutil.virtual_memory().total,
            "memory_available": psutil.virtual_memory().available,
            "disk_usage": {
                "total": psutil.disk_usage('/').total,
                "used": psutil.disk_usage('/').used,
                "free": psutil.disk_usage('/').free
            },
            "uptime": datetime.now().isoformat(),
            "version": "1.0.0"
        }
        
        return system_info
        
    except Exception as e:
        logger.error(f"System info error: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve system information")