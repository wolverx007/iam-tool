"""
Session management router for IAM Tool
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime
import logging

from database import get_db
from models import User, UserSession, SessionStatus
from services.session import SessionService
from dependencies import get_current_user, require_permission

router = APIRouter()
logger = logging.getLogger(__name__)

@router.get("/")
async def list_sessions(
    user_id: Optional[str] = Query(None),
    status: Optional[SessionStatus] = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List sessions with filtering"""
    try:
        session_service = SessionService(db)
        
        # Non-admin users can only see their own sessions
        if current_user.role.name not in ["admin", "manager"]:
            user_id = str(current_user.id)
        
        sessions, total = await session_service.list_sessions(
            user_id=user_id,
            status=status,
            skip=skip,
            limit=limit
        )
        
        return {
            "sessions": [
                {
                    "id": str(session.id),
                    "user_id": str(session.user_id),
                    "username": session.user.username,
                    "ip_address": session.ip_address,
                    "user_agent": session.user_agent,
                    "status": session.status.value,
                    "created_at": session.created_at.isoformat(),
                    "expires_at": session.expires_at.isoformat(),
                    "last_activity": session.last_activity.isoformat(),
                    "revoked_at": session.revoked_at.isoformat() if session.revoked_at else None
                }
                for session in sessions
            ],
            "total": total,
            "skip": skip,
            "limit": limit
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Session listing error: {e}")
        raise HTTPException(status_code=500, detail="Failed to list sessions")

@router.get("/{session_id}")
async def get_session(
    session_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get session by ID"""
    try:
        session_service = SessionService(db)
        
        session = await session_service.get_session_by_id(session_id)
        
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        # Check permissions
        if (session.user_id != current_user.id and 
            current_user.role.name not in ["admin", "manager"]):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to view this session"
            )
        
        return {
            "id": str(session.id),
            "user_id": str(session.user_id),
            "username": session.user.username,
            "ip_address": session.ip_address,
            "user_agent": session.user_agent,
            "status": session.status.value,
            "created_at": session.created_at.isoformat(),
            "expires_at": session.expires_at.isoformat(),
            "last_activity": session.last_activity.isoformat(),
            "revoked_at": session.revoked_at.isoformat() if session.revoked_at else None
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Session retrieval error: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve session")

@router.delete("/{session_id}")
async def revoke_session(
    session_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Revoke a session"""
    try:
        session_service = SessionService(db)
        
        session = await session_service.get_session_by_id(session_id)
        
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        # Check permissions
        if (session.user_id != current_user.id and 
            current_user.role.name not in ["admin", "manager"]):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to revoke this session"
            )
        
        success = await session_service.revoke_session(session_id)
        
        if not success:
            raise HTTPException(status_code=404, detail="Session not found")
        
        return {"success": True, "message": "Session revoked successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Session revocation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to revoke session")

@router.delete("/user/{user_id}")
async def revoke_user_sessions(
    user_id: str,
    current_user: User = Depends(require_permission("update_session")),
    db: Session = Depends(get_db)
):
    """Revoke all sessions for a user"""
    try:
        session_service = SessionService(db)
        
        # Check permissions
        if (user_id != str(current_user.id) and 
            current_user.role.name not in ["admin", "manager"]):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to revoke user sessions"
            )
        
        count = await session_service.revoke_user_sessions(user_id)
        
        return {
            "success": True,
            "message": f"Revoked {count} sessions successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"User session revocation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to revoke user sessions")

@router.post("/cleanup")
async def cleanup_expired_sessions(
    current_user: User = Depends(require_permission("admin")),
    db: Session = Depends(get_db)
):
    """Clean up expired sessions"""
    try:
        session_service = SessionService(db)
        
        count = await session_service.cleanup_expired_sessions()
        
        return {
            "success": True,
            "message": f"Cleaned up {count} expired sessions"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Session cleanup error: {e}")
        raise HTTPException(status_code=500, detail="Failed to cleanup sessions")

@router.get("/stats/active")
async def get_active_sessions_stats(
    current_user: User = Depends(require_permission("read_session")),
    db: Session = Depends(get_db)
):
    """Get active sessions statistics"""
    try:
        session_service = SessionService(db)
        
        stats = await session_service.get_active_sessions_stats()
        
        return stats
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Session stats error: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve session stats")

@router.get("/activity/{session_id}")
async def get_session_activity(
    session_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get session activity details"""
    try:
        session_service = SessionService(db)
        
        session = await session_service.get_session_by_id(session_id)
        
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        # Check permissions
        if (session.user_id != current_user.id and 
            current_user.role.name not in ["admin", "manager"]):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to view session activity"
            )
        
        activity = await session_service.get_session_activity(session_id)
        
        return activity
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Session activity error: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve session activity")

@router.post("/extend/{session_id}")
async def extend_session(
    session_id: str,
    extend_minutes: int = Query(60, ge=1, le=1440),  # 1 minute to 24 hours
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Extend session expiration"""
    try:
        session_service = SessionService(db)
        
        session = await session_service.get_session_by_id(session_id)
        
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        # Users can only extend their own sessions, admins can extend any
        if (session.user_id != current_user.id and 
            current_user.role.name not in ["admin", "manager"]):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to extend this session"
            )
        
        new_expiry = await session_service.extend_session(session_id, extend_minutes)
        
        if not new_expiry:
            raise HTTPException(status_code=404, detail="Session not found or cannot be extended")
        
        return {
            "success": True,
            "message": f"Session extended by {extend_minutes} minutes",
            "new_expiry": new_expiry.isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Session extension error: {e}")
        raise HTTPException(status_code=500, detail="Failed to extend session")