"""
Project management router for IAM Tool
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
import logging

from database import get_db
from models import User, Project
from schemas.projects import ProjectCreate, ProjectUpdate, ProjectResponse, ProjectListResponse
from services.project import ProjectService
from dependencies import get_current_user, require_permission

router = APIRouter()
logger = logging.getLogger(__name__)

@router.post("/", response_model=ProjectResponse)
async def create_project(
    project_data: ProjectCreate,
    current_user: User = Depends(require_permission("create_project")),
    db: Session = Depends(get_db)
):
    """Create a new project"""
    try:
        project_service = ProjectService(db)
        
        project = await project_service.create_project(project_data)
        
        return ProjectResponse.from_orm(project)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Project creation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to create project")

@router.get("/", response_model=ProjectListResponse)
async def list_projects(
    is_active: Optional[bool] = Query(True),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List projects"""
    try:
        project_service = ProjectService(db)
        
        # Non-admin users can only see their own project
        if current_user.role.name != "admin":
            projects = [current_user.project] if current_user.project.is_active else []
            total = len(projects)
        else:
            projects, total = await project_service.list_projects(
                is_active=is_active,
                skip=skip,
                limit=limit
            )
        
        return ProjectListResponse(
            projects=[ProjectResponse.from_orm(project) for project in projects],
            total=total,
            skip=skip,
            limit=limit
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Project listing error: {e}")
        raise HTTPException(status_code=500, detail="Failed to list projects")

@router.get("/{project_id}", response_model=ProjectResponse)
async def get_project(
    project_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get project by ID"""
    try:
        project_service = ProjectService(db)
        
        project = await project_service.get_project_by_id(project_id)
        
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        
        # Check if user can access this project
        if (project.id != current_user.project_id and 
            current_user.role.name != "admin"):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to access this project"
            )
        
        return ProjectResponse.from_orm(project)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Project retrieval error: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve project")

@router.put("/{project_id}", response_model=ProjectResponse)
async def update_project(
    project_id: str,
    project_data: ProjectUpdate,
    current_user: User = Depends(require_permission("update_project")),
    db: Session = Depends(get_db)
):
    """Update project"""
    try:
        project_service = ProjectService(db)
        
        # Get existing project
        existing_project = await project_service.get_project_by_id(project_id)
        
        if not existing_project:
            raise HTTPException(status_code=404, detail="Project not found")
        
        # Check permissions
        if (existing_project.id != current_user.project_id and 
            current_user.role.name != "admin"):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to update this project"
            )
        
        project = await project_service.update_project(project_id, project_data)
        
        return ProjectResponse.from_orm(project)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Project update error: {e}")
        raise HTTPException(status_code=500, detail="Failed to update project")

@router.delete("/{project_id}")
async def delete_project(
    project_id: str,
    current_user: User = Depends(require_permission("delete_project")),
    db: Session = Depends(get_db)
):
    """Delete project (soft delete)"""
    try:
        project_service = ProjectService(db)
        
        # Get existing project
        existing_project = await project_service.get_project_by_id(project_id)
        
        if not existing_project:
            raise HTTPException(status_code=404, detail="Project not found")
        
        # Only admin can delete projects
        if current_user.role.name != "admin":
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to delete project"
            )
        
        success = await project_service.delete_project(project_id)
        
        if not success:
            raise HTTPException(status_code=404, detail="Project not found")
        
        return {"success": True, "message": "Project deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Project deletion error: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete project")

@router.get("/{project_id}/stats")
async def get_project_stats(
    project_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get project statistics"""
    try:
        project_service = ProjectService(db)
        
        # Check permissions
        if (project_id != str(current_user.project_id) and 
            current_user.role.name != "admin"):
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to view project stats"
            )
        
        stats = await project_service.get_project_stats(project_id)
        
        return stats
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Project stats error: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve project stats")

@router.post("/{project_id}/activate")
async def activate_project(
    project_id: str,
    current_user: User = Depends(require_permission("update_project")),
    db: Session = Depends(get_db)
):
    """Activate project"""
    try:
        project_service = ProjectService(db)
        
        # Only admin can activate/deactivate projects
        if current_user.role.name != "admin":
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to activate project"
            )
        
        success = await project_service.activate_project(project_id)
        
        if not success:
            raise HTTPException(status_code=404, detail="Project not found")
        
        return {"success": True, "message": "Project activated successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Project activation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to activate project")

@router.post("/{project_id}/deactivate")
async def deactivate_project(
    project_id: str,
    current_user: User = Depends(require_permission("update_project")),
    db: Session = Depends(get_db)
):
    """Deactivate project"""
    try:
        project_service = ProjectService(db)
        
        # Only admin can activate/deactivate projects
        if current_user.role.name != "admin":
            raise HTTPException(
                status_code=403,
                detail="Insufficient permissions to deactivate project"
            )
        
        success = await project_service.deactivate_project(project_id)
        
        if not success:
            raise HTTPException(status_code=404, detail="Project not found")
        
        return {"success": True, "message": "Project deactivated successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Project deactivation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to deactivate project")