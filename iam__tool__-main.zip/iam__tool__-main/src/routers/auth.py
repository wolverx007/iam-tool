"""
Authentication router for IAM Tool
"""
from fastapi import APIRouter, Depends, HTTPException, Request, Response, Form
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr
from typing import Optional
import logging

from database import get_db
from services.auth import AuthService
from services.security import SecurityService
from models import User, UserSession, AALLevel
from schemas.auth import LoginRequest, LoginResponse, RegisterRequest, TotpVerificationRequest
from dependencies import get_current_user, require_aal
from slowapi import Limiter
from slowapi.util import get_remote_address

router = APIRouter()
security = HTTPBearer()
limiter = Limiter(key_func=get_remote_address)
logger = logging.getLogger(__name__)

# Schemas
class PasswordChangeRequest(BaseModel):
    current_password: str
    new_password: str

class PasswordResetRequest(BaseModel):
    email: EmailStr

class PasswordResetConfirmRequest(BaseModel):
    token: str
    new_password: str

@router.post("/login", response_model=LoginResponse)
@limiter.limit("10/minute")
async def login(
    request: Request,
    login_data: LoginRequest,
    db: Session = Depends(get_db)
):
    """Authenticate user and create session"""
    try:
        auth_service = AuthService(db)
        security_service = SecurityService()
        
        # Get client IP and user agent
        client_ip = request.client.host
        user_agent = request.headers.get("User-Agent", "")
        
        # Authenticate user
        result = await auth_service.authenticate_user(
            username=login_data.username,
            password=login_data.password,
            project_name=login_data.project,
            client_ip=client_ip,
            user_agent=user_agent
        )
        
        if not result.success:
            raise HTTPException(
                status_code=401,
                detail=result.message
            )
        
        # Check if additional factors required
        if result.requires_mfa:
            return LoginResponse(
                success=True,
                requires_mfa=True,
                mfa_methods=result.mfa_methods,
                temp_token=result.temp_token,
                message="Additional authentication required"
            )
        
        # Create session
        session = await auth_service.create_session(
            user=result.user,
            client_ip=client_ip,
            user_agent=user_agent
        )
        
        return LoginResponse(
            success=True,
            access_token=session.session_token,
            refresh_token=session.refresh_token,
            expires_in=security_service.get_session_timeout(),
            user_id=str(result.user.id),
            username=result.user.username,
            role=result.user.role.name,
            aal_level=result.user.role.aal_level.value
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Login error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/verify-totp")
@limiter.limit("10/minute")
async def verify_totp(
    request: Request,
    verification_data: TotpVerificationRequest,
    db: Session = Depends(get_db)
):
    """Verify TOTP code for MFA"""
    try:
        auth_service = AuthService(db)
        
        result = await auth_service.verify_totp(
            temp_token=verification_data.temp_token,
            totp_code=verification_data.totp_code,
            client_ip=request.client.host,
            user_agent=request.headers.get("User-Agent", "")
        )
        
        if not result.success:
            raise HTTPException(status_code=401, detail=result.message)
        
        return LoginResponse(
            success=True,
            access_token=result.access_token,
            refresh_token=result.refresh_token,
            expires_in=result.expires_in,
            user_id=result.user_id,
            username=result.username,
            role=result.role,
            aal_level=result.aal_level
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"TOTP verification error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/logout")
async def logout(
    request: Request,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
):
    """Logout user and revoke session"""
    try:
        auth_service = AuthService(db)
        
        result = await auth_service.logout_user(credentials.credentials)
        
        if not result:
            raise HTTPException(status_code=401, detail="Invalid session")
        
        return {"success": True, "message": "Logged out successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Logout error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/refresh")
@limiter.limit("30/minute")
async def refresh_token(
    request: Request,
    refresh_token: str = Form(...),
    db: Session = Depends(get_db)
):
    """Refresh access token"""
    try:
        auth_service = AuthService(db)
        
        result = await auth_service.refresh_token(refresh_token)
        
        if not result.success:
            raise HTTPException(status_code=401, detail=result.message)
        
        return {
            "access_token": result.access_token,
            "expires_in": result.expires_in
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Token refresh error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/change-password")
async def change_password(
    request: Request,
    password_data: PasswordChangeRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Change user password"""
    try:
        auth_service = AuthService(db)
        
        result = await auth_service.change_password(
            user=current_user,
            current_password=password_data.current_password,
            new_password=password_data.new_password
        )
        
        if not result.success:
            raise HTTPException(status_code=400, detail=result.message)
        
        return {"success": True, "message": "Password changed successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Password change error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/forgot-password")
@limiter.limit("5/hour")
async def forgot_password(
    request: Request,
    reset_data: PasswordResetRequest,
    db: Session = Depends(get_db)
):
    """Request password reset"""
    try:
        auth_service = AuthService(db)
        
        result = await auth_service.request_password_reset(reset_data.email)
        
        # Always return success to prevent email enumeration
        return {"success": True, "message": "Password reset email sent if account exists"}
        
    except Exception as e:
        logger.error(f"Password reset request error: {e}")
        # Still return success to prevent information disclosure
        return {"success": True, "message": "Password reset email sent if account exists"}

@router.post("/reset-password")
@limiter.limit("5/hour")
async def reset_password(
    request: Request,
    reset_data: PasswordResetConfirmRequest,
    db: Session = Depends(get_db)
):
    """Confirm password reset"""
    try:
        auth_service = AuthService(db)
        
        result = await auth_service.reset_password(
            token=reset_data.token,
            new_password=reset_data.new_password
        )
        
        if not result.success:
            raise HTTPException(status_code=400, detail=result.message)
        
        return {"success": True, "message": "Password reset successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Password reset error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/me")
async def get_current_user_info(
    current_user: User = Depends(get_current_user)
):
    """Get current user information"""
    return {
        "id": str(current_user.id),
        "username": current_user.username,
        "email": current_user.email,
        "first_name": current_user.first_name,
        "last_name": current_user.last_name,
        "project": current_user.project.name,
        "role": current_user.role.name,
        "aal_level": current_user.role.aal_level.value,
        "permissions": current_user.role.permissions,
        "is_verified": current_user.is_verified,
        "last_login": current_user.last_login.isoformat() if current_user.last_login else None
    }

@router.get("/sessions")
async def get_user_sessions(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get user's active sessions"""
    sessions = db.query(UserSession).filter(
        UserSession.user_id == current_user.id,
        UserSession.status == "ACTIVE"
    ).all()
    
    return [
        {
            "id": str(session.id),
            "ip_address": session.ip_address,
            "user_agent": session.user_agent,
            "created_at": session.created_at.isoformat(),
            "last_activity": session.last_activity.isoformat(),
            "expires_at": session.expires_at.isoformat()
        }
        for session in sessions
    ]

@router.delete("/sessions/{session_id}")
async def revoke_session(
    session_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Revoke a specific session"""
    try:
        auth_service = AuthService(db)
        
        result = await auth_service.revoke_user_session(
            user=current_user,
            session_id=session_id
        )
        
        if not result:
            raise HTTPException(status_code=404, detail="Session not found")
        
        return {"success": True, "message": "Session revoked"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Session revocation error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")