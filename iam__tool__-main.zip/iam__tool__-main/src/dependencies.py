"""
FastAPI dependencies for IAM Tool
"""
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from typing import Optional
import logging

from database import get_db
from models import User, AALLevel
from services.auth import AuthService

logger = logging.getLogger(__name__)
security = HTTPBearer()

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
) -> User:
    """Get current authenticated user"""
    try:
        auth_service = AuthService(db)
        
        # Validate session
        session = await auth_service.validate_session(credentials.credentials)
        
        if not session:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired session",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        # Get user
        user = db.query(User).filter(User.id == session.user_id).first()
        
        if not user or not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found or inactive",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        return user
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Authentication error: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication failed",
            headers={"WWW-Authenticate": "Bearer"},
        )

def require_aal(required_aal: AALLevel):
    """Require specific AAL level"""
    def aal_dependency(current_user: User = Depends(get_current_user)) -> User:
        user_aal = current_user.role.aal_level
        
        # AAL hierarchy: GUEST < AAL1 < AAL2 < AAL3
        aal_levels = {
            AALLevel.GUEST: 0,
            AALLevel.AAL1: 1,
            AALLevel.AAL2: 2,
            AALLevel.AAL3: 3,
            AALLevel.CUSTOM: 2  # Treat custom as AAL2 equivalent
        }
        
        if aal_levels.get(user_aal, 0) < aal_levels.get(required_aal, 0):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Insufficient authentication level. Required: {required_aal.value}, Current: {user_aal.value}"
            )
        
        return current_user
    
    return aal_dependency

def require_permission(permission: str):
    """Require specific permission"""
    def permission_dependency(current_user: User = Depends(get_current_user)) -> User:
        user_permissions = current_user.role.permissions or []
        
        # Admin role has all permissions
        if current_user.role.name == "admin":
            return current_user
        
        if permission not in user_permissions:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Insufficient permissions. Required: {permission}"
            )
        
        return current_user
    
    return permission_dependency

def require_admin(current_user: User = Depends(get_current_user)) -> User:
    """Require admin role"""
    if current_user.role.name != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required"
        )
    
    return current_user

def require_manager_or_admin(current_user: User = Depends(get_current_user)) -> User:
    """Require manager or admin role"""
    if current_user.role.name not in ["admin", "manager"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Manager or admin access required"
        )
    
    return current_user

def require_same_project(target_project_id: str):
    """Require user to be in the same project"""
    def project_dependency(current_user: User = Depends(get_current_user)) -> User:
        # Admin can access all projects
        if current_user.role.name == "admin":
            return current_user
        
        if str(current_user.project_id) != target_project_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied. Different project."
            )
        
        return current_user
    
    return project_dependency

async def get_optional_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(HTTPBearer(auto_error=False)),
    db: Session = Depends(get_db)
) -> Optional[User]:
    """Get current user if authenticated, otherwise return None"""
    if not credentials:
        return None
    
    try:
        auth_service = AuthService(db)
        session = await auth_service.validate_session(credentials.credentials)
        
        if not session:
            return None
        
        user = db.query(User).filter(User.id == session.user_id).first()
        
        if not user or not user.is_active:
            return None
        
        return user
        
    except Exception as e:
        logger.error(f"Optional authentication error: {e}")
        return None

def require_verified_user(current_user: User = Depends(get_current_user)) -> User:
    """Require user to have verified email"""
    if not current_user.is_verified:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Email verification required"
        )
    
    return current_user

def require_active_user(current_user: User = Depends(get_current_user)) -> User:
    """Require user to be active (not locked)"""
    if not current_user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is inactive"
        )
    
    if current_user.locked_until and current_user.locked_until > datetime.utcnow():
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is temporarily locked"
        )
    
    return current_user

class RoleChecker:
    """Role-based access control checker"""
    
    def __init__(self, allowed_roles: list):
        self.allowed_roles = allowed_roles
    
    def __call__(self, current_user: User = Depends(get_current_user)) -> User:
        if current_user.role.name not in self.allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access denied. Required roles: {', '.join(self.allowed_roles)}"
            )
        
        return current_user

class PermissionChecker:
    """Permission-based access control checker"""
    
    def __init__(self, required_permissions: list):
        self.required_permissions = required_permissions
    
    def __call__(self, current_user: User = Depends(get_current_user)) -> User:
        user_permissions = current_user.role.permissions or []
        
        # Admin has all permissions
        if current_user.role.name == "admin":
            return current_user
        
        # Check if user has all required permissions
        missing_permissions = [
            perm for perm in self.required_permissions 
            if perm not in user_permissions
        ]
        
        if missing_permissions:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Missing permissions: {', '.join(missing_permissions)}"
            )
        
        return current_user

# Common permission checkers
require_read_user = PermissionChecker(["read_user"])
require_create_user = PermissionChecker(["create_user"])
require_update_user = PermissionChecker(["update_user"])
require_delete_user = PermissionChecker(["delete_user"])

require_read_role = PermissionChecker(["read_role"])
require_create_role = PermissionChecker(["create_role"])
require_update_role = PermissionChecker(["update_role"])
require_delete_role = PermissionChecker(["delete_role"])

require_read_project = PermissionChecker(["read_project"])
require_create_project = PermissionChecker(["create_project"])
require_update_project = PermissionChecker(["update_project"])
require_delete_project = PermissionChecker(["delete_project"])

require_read_session = PermissionChecker(["read_session"])
require_update_session = PermissionChecker(["update_session"])
require_delete_session = PermissionChecker(["delete_session"])

# Common role checkers
require_admin_role = RoleChecker(["admin"])
require_manager_role = RoleChecker(["admin", "manager"])
require_user_role = RoleChecker(["admin", "manager", "user"])