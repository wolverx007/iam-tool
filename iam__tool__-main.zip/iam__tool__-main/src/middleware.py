"""
Custom middleware for IAM Tool
"""
from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
import time
import logging
import uuid
from datetime import datetime

from models import AuditLog, AuditAction
from database import SessionLocal

logger = logging.getLogger(__name__)

class SecurityMiddleware(BaseHTTPMiddleware):
    """Security headers and CSRF protection middleware"""
    
    def __init__(self, app: ASGIApp):
        super().__init__(app)
    
    async def dispatch(self, request: Request, call_next):
        # Add request ID for tracing
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id
        
        # Add security headers
        response = await call_next(request)
        
        # Security headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
            "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
            "img-src 'self' data: https:; "
            "font-src 'self' https://cdnjs.cloudflare.com; "
            "connect-src 'self'; "
            "frame-ancestors 'none';"
        )
        
        # Add request ID to response
        response.headers["X-Request-ID"] = request_id
        
        return response

class AuditMiddleware(BaseHTTPMiddleware):
    """Audit logging middleware"""
    
    def __init__(self, app: ASGIApp):
        super().__init__(app)
        self.audit_paths = [
            "/api/auth/login",
            "/api/auth/logout",
            "/api/users",
            "/api/projects",
            "/api/roles",
            "/api/admin"
        ]
    
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        
        # Check if this request should be audited
        should_audit = any(request.url.path.startswith(path) for path in self.audit_paths)
        
        response = await call_next(request)
        
        if should_audit:
            process_time = time.time() - start_time
            await self._log_request(request, response, process_time)
        
        return response
    
    async def _log_request(self, request: Request, response: Response, process_time: float):
        """Log request to audit table"""
        try:
            # Extract user info if available
            user_id = None
            if hasattr(request.state, 'user'):
                user_id = request.state.user.id
            
            # Determine action based on method and path
            action = self._determine_action(request.method, request.url.path)
            
            # Create audit log entry
            db = SessionLocal()
            try:
                audit_log = AuditLog(
                    user_id=user_id,
                    action=action,
                    resource_type=self._extract_resource_type(request.url.path),
                    resource_id=self._extract_resource_id(request.url.path),
                    ip_address=self._get_client_ip(request),
                    user_agent=request.headers.get("User-Agent", ""),
                    success=200 <= response.status_code < 400,
                    details={
                        "method": request.method,
                        "path": str(request.url.path),
                        "status_code": response.status_code,
                        "process_time": round(process_time, 3),
                        "request_id": getattr(request.state, 'request_id', None)
                    }
                )
                
                db.add(audit_log)
                db.commit()
                
            finally:
                db.close()
                
        except Exception as e:
            logger.error(f"Audit logging error: {e}")
    
    def _determine_action(self, method: str, path: str) -> AuditAction:
        """Determine audit action from HTTP method and path"""
        if "login" in path:
            return AuditAction.LOGIN
        elif "logout" in path:
            return AuditAction.LOGOUT
        elif method == "POST":
            return AuditAction.CREATE
        elif method in ["PUT", "PATCH"]:
            return AuditAction.UPDATE
        elif method == "DELETE":
            return AuditAction.DELETE
        else:
            return AuditAction.ACCESS
    
    def _extract_resource_type(self, path: str) -> str:
        """Extract resource type from path"""
        if "/users" in path:
            return "user"
        elif "/projects" in path:
            return "project"
        elif "/roles" in path:
            return "role"
        elif "/sessions" in path:
            return "session"
        elif "/admin" in path:
            return "admin"
        else:
            return "unknown"
    
    def _extract_resource_id(self, path: str) -> str:
        """Extract resource ID from path"""
        parts = path.split("/")
        for i, part in enumerate(parts):
            if part in ["users", "projects", "roles", "sessions"] and i + 1 < len(parts):
                return parts[i + 1]
        return ""
    
    def _get_client_ip(self, request: Request) -> str:
        """Get client IP address"""
        # Check for forwarded headers first
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
        
        real_ip = request.headers.get("X-Real-IP")
        if real_ip:
            return real_ip
        
        return request.client.host if request.client else "unknown"

class RateLimitMiddleware(BaseHTTPMiddleware):
    """Rate limiting middleware"""
    
    def __init__(self, app: ASGIApp):
        super().__init__(app)
        self.rate_limits = {}  # In production, use Redis
        self.window_size = 60  # 1 minute window
        self.max_requests = 100  # Max requests per window
    
    async def dispatch(self, request: Request, call_next):
        client_ip = self._get_client_ip(request)
        current_time = time.time()
        
        # Clean old entries
        self._cleanup_old_entries(current_time)
        
        # Check rate limit
        if self._is_rate_limited(client_ip, current_time):
            return JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded. Please try again later."},
                headers={"Retry-After": "60"}
            )
        
        # Record request
        self._record_request(client_ip, current_time)
        
        return await call_next(request)
    
    def _get_client_ip(self, request: Request) -> str:
        """Get client IP address"""
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
        
        return request.client.host if request.client else "unknown"
    
    def _is_rate_limited(self, client_ip: str, current_time: float) -> bool:
        """Check if client is rate limited"""
        if client_ip not in self.rate_limits:
            return False
        
        requests = self.rate_limits[client_ip]
        recent_requests = [req_time for req_time in requests 
                          if current_time - req_time < self.window_size]
        
        return len(recent_requests) >= self.max_requests
    
    def _record_request(self, client_ip: str, current_time: float):
        """Record request timestamp"""
        if client_ip not in self.rate_limits:
            self.rate_limits[client_ip] = []
        
        self.rate_limits[client_ip].append(current_time)
    
    def _cleanup_old_entries(self, current_time: float):
        """Clean up old rate limit entries"""
        for client_ip in list(self.rate_limits.keys()):
            requests = self.rate_limits[client_ip]
            recent_requests = [req_time for req_time in requests 
                              if current_time - req_time < self.window_size]
            
            if recent_requests:
                self.rate_limits[client_ip] = recent_requests
            else:
                del self.rate_limits[client_ip]

class MaintenanceMiddleware(BaseHTTPMiddleware):
    """Maintenance mode middleware"""
    
    def __init__(self, app: ASGIApp):
        super().__init__(app)
        self.maintenance_mode = False
        self.maintenance_message = "System is under maintenance"
        self.allowed_paths = ["/health", "/admin/maintenance"]
    
    async def dispatch(self, request: Request, call_next):
        if self.maintenance_mode and request.url.path not in self.allowed_paths:
            return JSONResponse(
                status_code=503,
                content={
                    "detail": self.maintenance_message,
                    "maintenance": True
                },
                headers={"Retry-After": "3600"}
            )
        
        return await call_next(request)
    
    def enable_maintenance(self, message: str = None):
        """Enable maintenance mode"""
        self.maintenance_mode = True
        if message:
            self.maintenance_message = message
    
    def disable_maintenance(self):
        """Disable maintenance mode"""
        self.maintenance_mode = False