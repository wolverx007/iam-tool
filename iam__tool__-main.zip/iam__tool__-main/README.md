# IAM Tool - Production Identity and Access Management System

A complete IAM solution with CLI and web dashboard, built for Linux servers with NIST SP 800-63B compliance.

## 🚀 Quick Start

```bash
# Clone and install
git clone <repository-url> iam-tool
cd iam-tool
chmod +x install.sh
sudo ./install.sh

# Start the service
sudo systemctl start iam
sudo systemctl enable iam

# Create your first project
iamctl project create myapp --desc "My Application"
iamctl role create myapp admin
iamctl user add admin alice
iamctl map admin --aal AAL2
```

## 🏗️ Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Web Dashboard │    │    CLI Tool     │    │  External Apps  │
│   (FastAPI)     │    │   (iamctl)      │    │   (OIDC)        │
└─────────┬───────┘    └─────────┬───────┘    └─────────┬───────┘
          │                      │                      │
          └──────────────────────┼──────────────────────┘
                                 │
                    ┌─────────────▼──────────────┐
                    │        IAM Core            │
                    │     (FastAPI Backend)      │
                    └─────────────┬──────────────┘
                                 │
        ┌────────────────────────┼────────────────────────┐
        │                       │                        │
┌───────▼────────┐    ┌─────────▼─────────┐    ┌─────────▼─────────┐
│   PostgreSQL   │    │  HashiCorp Vault  │    │     Plugins       │
│   (Main DB)    │    │   (Secrets)       │    │  (TOTP, WebAuthn) │
└────────────────┘    └───────────────────┘    └───────────────────┘
```

## 🔐 Authentication Levels

- **AAL1**: Username + Password (Argon2id hashed)
- **AAL2**: Username + Password + TOTP/SMS
- **AAL3**: WebAuthn (FIDO2, Hardware tokens, Biometrics)
- **Custom**: Admin-defined authentication flows

## 📋 Features

### Core Features
- Multi-project isolation
- Role-Based Access Control (RBAC)
- NIST SP 800-63B compliant authentication
- Plugin-based architecture
- OIDC integration for external apps
- Session management and monitoring
- Audit logging

### Security Features
- Argon2id password hashing
- CSRF/XSS protection
- Rate limiting and account lockout
- JWT/PASETO session tokens
- TLS/HTTPS support
- HashiCorp Vault integration

### Management Features
- Web-based admin dashboard
- CLI management tool
- Custom login page support
- Email notifications
- Backup/restore functionality

## 🛠️ Installation

### Prerequisites
- Ubuntu 20.04+ / Debian 11+ / CentOS 8+
- Root or sudo access
- 2GB RAM minimum
- 10GB disk space

### Automatic Installation
```bash
curl -sSL https://raw.githubusercontent.com/your-repo/iam-tool/main/install.sh | sudo bash
```

### Manual Installation
```bash
git clone <repository-url> iam-tool
cd iam-tool
chmod +x install.sh
sudo ./install.sh
```

## 📚 CLI Usage

### Project Management
```bash
# Create a new project
iamctl project create ecommerce --desc "E-commerce website"

# List projects
iamctl project list

# Delete project
iamctl project delete ecommerce
```

### User Management
```bash
# Create roles
iamctl role create ecommerce admin
iamctl role create ecommerce user
iamctl role create ecommerce guest

# Add users
iamctl user add admin alice --email alice@example.com
iamctl user add user bob --email bob@example.com

# Map roles to security levels
iamctl map admin --aal AAL3
iamctl map user --aal AAL1
iamctl map guest --aal GUEST
```

### Site Integration
```bash
# Register external application
iamctl site add ecommerce --url https://shop.example.com --callback https://shop.example.com/auth/callback

# List registered sites
iamctl site list ecommerce
```

### Session Management
```bash
# List active sessions
iamctl session list

# Revoke user sessions
iamctl session revoke alice

# View session details
iamctl session show <session-id>
```

## 🌐 Web Dashboard

Access the web dashboard at `https://your-server:8443`

### Default Credentials
- Username: `admin`
- Password: `changeme123!`

**⚠️ Change the default password immediately after installation**

### Dashboard Features
- User and role management
- Session monitoring
- Policy configuration
- Integration management
- Audit logs
- Custom login page upload

## 🔌 Integration

### OIDC Integration
```javascript
// JavaScript example
const oidc = new OIDCClient({
  authority: 'https://your-iam-server:8443',
  client_id: 'your-client-id',
  redirect_uri: 'https://your-app.com/callback',
  response_type: 'code',
  scope: 'openid profile email'
});
```

### Direct API Integration
```python
# Python example
import requests

response = requests.post('https://your-iam-server:8443/api/auth/login', {
  'username': 'alice',
  'password': 'secret123',
  'project': 'ecommerce'
})

if response.status_code == 200:
    token = response.json()['access_token']
    # Use token for subsequent requests
```

## 🔧 Configuration

### Main Configuration
Edit `/etc/iam/config.yaml`:

```yaml
server:
  host: "0.0.0.0"
  port: 8443
  ssl_cert: "/etc/iam/ssl/server.crt"
  ssl_key: "/etc/iam/ssl/server.key"

database:
  url: "postgresql://iam_user:password@localhost/iam_db"

vault:
  url: "http://localhost:8200"
  token_file: "/etc/iam/vault_token"

security:
  session_timeout: 3600
  max_login_attempts: 5
  lockout_duration: 300

plugins:
  enabled:
    - totp
    - webauthn
    - email
```

## 🔐 Security Configuration

### TLS Certificates
```bash
# Generate self-signed certificate
sudo openssl req -x509 -newkey rsa:4096 -keyout /etc/iam/ssl/server.key -out /etc/iam/ssl/server.crt -days 365 -nodes

# Or use Let's Encrypt
sudo certbot certonly --standalone -d your-iam-server.com
sudo ln -s /etc/letsencrypt/live/your-iam-server.com/fullchain.pem /etc/iam/ssl/server.crt
sudo ln -s /etc/letsencrypt/live/your-iam-server.com/privkey.pem /etc/iam/ssl/server.key
```

### Firewall Configuration
```bash
# Ubuntu/Debian
sudo ufw allow 8443/tcp
sudo ufw enable

# CentOS/RHEL
sudo firewall-cmd --add-port=8443/tcp --permanent
sudo firewall-cmd --reload
```

## 🧩 Plugin Development

### Creating a Custom Plugin
```python
# /opt/iam/plugins/my_plugin.py
from iam.plugins.base import BasePlugin

class MyPlugin(BasePlugin):
    name = "my_plugin"
    version = "1.0.0"
    
    def authenticate(self, credentials):
        # Custom authentication logic
        pass
    
    def authorize(self, user, resource):
        # Custom authorization logic
        pass
```

### Plugin Configuration
```yaml
# /etc/iam/plugins/my_plugin.yaml
enabled: true
settings:
  api_key: "your-api-key"
  endpoint: "https://api.example.com"
```

## 📊 Monitoring and Logging

### Service Status
```bash
# Check service status
sudo systemctl status iam

# View logs
sudo journalctl -u iam -f

# Check configuration
iamctl config check
```

### Log Files
- Application logs: `/var/log/iam/app.log`
- Access logs: `/var/log/iam/access.log`
- Audit logs: `/var/log/iam/audit.log`
- Error logs: `/var/log/iam/error.log`

## 🔄 Backup and Restore

### Backup
```bash
# Create full backup
sudo iamctl backup create --output /backup/iam-$(date +%Y%m%d).tar.gz

# Backup database only
sudo iamctl backup db --output /backup/iam-db-$(date +%Y%m%d).sql
```

### Restore
```bash
# Restore from backup
sudo iamctl restore --input /backup/iam-20241201.tar.gz

# Restore database only
sudo iamctl restore db --input /backup/iam-db-20241201.sql
```

## 🚨 Troubleshooting

### Common Issues

**Service won't start**
```bash
sudo journalctl -u iam --no-pager
# Check configuration and permissions
```

**Database connection issues**
```bash
# Test database connection
sudo -u iam pg_isready -h localhost -p 5432 -d iam_db
```

**Vault unsealing**
```bash
# Check Vault status
vault status
# Unseal if needed
vault operator unseal
```

**Permission issues**
```bash
# Fix file permissions
sudo chown -R iam:iam /opt/iam
sudo chmod 644 /etc/iam/config.yaml
sudo chmod 600 /etc/iam/ssl/server.key
```

## 📖 API Documentation

Interactive API documentation available at:
- Swagger UI: `https://your-server:8443/docs`
- ReDoc: `https://your-server:8443/redoc`

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

- Documentation: https://docs.iam-tool.com
- Issues: https://github.com/your-repo/iam-tool/issues
- Community: https://discord.gg/iam-tool

## 🔄 Changelog

### v1.0.0
- Initial release
- NIST SP 800-63B compliance
- Multi-project support
- OIDC integration
- Plugin system
- Web dashboard
- CLI tool