#!/bin/bash

# IAM Tool Installation Script
# Supports Ubuntu 20.04+, Debian 11+, CentOS 8+

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
IAM_USER="iam"
IAM_GROUP="iam"
IAM_HOME="/opt/iam"
CONFIG_DIR="/etc/iam"
LOG_DIR="/var/log/iam"
VAULT_VERSION="1.15.4"
POSTGRESQL_VERSION="15"

# Detect OS
detect_os() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        OS=$ID
        VER=$VERSION_ID
    else
        echo -e "${RED}Cannot detect OS${NC}"
        exit 1
    fi
    
    echo -e "${BLUE}Detected OS: $OS $VER${NC}"
}

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}This script must be run as root${NC}"
        exit 1
    fi
}

# Print banner
print_banner() {
    echo -e "${BLUE}"
    cat << "EOF"
  ___    _    __  __   _____           _ 
 |_ _|  / \  |  \/  | |_   _|__   ___ | |
  | |  / _ \ | |\/| |   | |/ _ \ / _ \| |
  | | / ___ \| |  | |   | | (_) | (_) | |
 |___/_/   \_\_|  |_|   |_|\___/ \___/|_|
                                        
 Identity and Access Management System
EOF
    echo -e "${NC}"
}

# Install system dependencies
install_dependencies() {
    echo -e "${YELLOW}Installing system dependencies...${NC}"
    
    case $OS in
        ubuntu|debian)
            apt-get update
            apt-get install -y \
                python3 \
                python3-pip \
                python3-venv \
                postgresql-$POSTGRESQL_VERSION \
                postgresql-client-$POSTGRESQL_VERSION \
                nginx \
                curl \
                wget \
                unzip \
                openssl \
                build-essential \
                libpq-dev \
                python3-dev \
                libffi-dev \
                libssl-dev \
                redis-server \
                postfix
            ;;
        centos|rhel|fedora)
            if command -v dnf &> /dev/null; then
                dnf install -y epel-release
                dnf install -y \
                    python3 \
                    python3-pip \
                    postgresql$POSTGRESQL_VERSION-server \
                    postgresql$POSTGRESQL_VERSION \
                    nginx \
                    curl \
                    wget \
                    unzip \
                    openssl \
                    gcc \
                    postgresql-devel \
                    python3-devel \
                    libffi-devel \
                    openssl-devel \
                    redis \
                    postfix
            else
                yum install -y epel-release
                yum install -y \
                    python3 \
                    python3-pip \
                    postgresql$POSTGRESQL_VERSION-server \
                    postgresql$POSTGRESQL_VERSION \
                    nginx \
                    curl \
                    wget \
                    unzip \
                    openssl \
                    gcc \
                    postgresql-devel \
                    python3-devel \
                    libffi-devel \
                    openssl-devel \
                    redis \
                    postfix
            fi
            ;;
        *)
            echo -e "${RED}Unsupported OS: $OS${NC}"
            exit 1
            ;;
    esac
}

# Create system user and directories
create_user_and_dirs() {
    echo -e "${YELLOW}Creating IAM user and directories...${NC}"
    
    # Create system user
    if ! id "$IAM_USER" &>/dev/null; then
        useradd --system --create-home --home-dir "$IAM_HOME" --shell /bin/bash "$IAM_USER"
    fi
    
    # Create directories
    mkdir -p "$IAM_HOME"/{bin,lib,plugins,templates,static}
    mkdir -p "$CONFIG_DIR"/{ssl,plugins}
    mkdir -p "$LOG_DIR"
    mkdir -p /var/lib/iam
    
    # Set permissions
    chown -R "$IAM_USER:$IAM_GROUP" "$IAM_HOME"
    chown -R "$IAM_USER:$IAM_GROUP" "$LOG_DIR"
    chown -R "$IAM_USER:$IAM_GROUP" /var/lib/iam
    chmod 755 "$CONFIG_DIR"
    chmod 700 "$CONFIG_DIR/ssl"
}

# Install HashiCorp Vault
install_vault() {
    echo -e "${YELLOW}Installing HashiCorp Vault...${NC}"
    
    # Download and install Vault
    cd /tmp
    wget -q "https://releases.hashicorp.com/vault/${VAULT_VERSION}/vault_${VAULT_VERSION}_linux_amd64.zip"
    unzip vault_${VAULT_VERSION}_linux_amd64.zip
    mv vault /usr/local/bin/
    chmod +x /usr/local/bin/vault
    
    # Create Vault directories
    mkdir -p /etc/vault.d
    mkdir -p /var/lib/vault
    chown -R vault:vault /var/lib/vault
    
    # Create vault user
    if ! id "vault" &>/dev/null; then
        useradd --system --create-home --home-dir /var/lib/vault --shell /bin/bash vault
    fi
    
    # Vault configuration
    cat > /etc/vault.d/vault.hcl << 'EOF'
ui = true
storage "file" {
  path = "/var/lib/vault/data"
}

listener "tcp" {
  address = "127.0.0.1:8200"
  tls_disable = 1
}

api_addr = "http://127.0.0.1:8200"
cluster_addr = "https://127.0.0.1:8201"
EOF
    
    chown vault:vault /etc/vault.d/vault.hcl
    chmod 640 /etc/vault.d/vault.hcl
}

# Setup PostgreSQL
setup_postgresql() {
    echo -e "${YELLOW}Setting up PostgreSQL...${NC}"
    
    # Initialize PostgreSQL (CentOS/RHEL)
    if [[ "$OS" == "centos" || "$OS" == "rhel" ]]; then
        postgresql-$POSTGRESQL_VERSION-setup initdb
    fi
    
    # Start and enable PostgreSQL
    systemctl start postgresql
    systemctl enable postgresql
    
    # Create IAM database and user
    sudo -u postgres psql << EOF
CREATE USER iam_user WITH PASSWORD 'iam_secure_password_$(openssl rand -hex 16)';
CREATE DATABASE iam_db OWNER iam_user;
GRANT ALL PRIVILEGES ON DATABASE iam_db TO iam_user;
\q
EOF
    
    # Store database credentials
    DB_PASSWORD=$(sudo -u postgres psql -t -c "SELECT rolpassword FROM pg_authid WHERE rolname='iam_user';" | tr -d ' ')
    echo "DATABASE_URL=postgresql://iam_user:${DB_PASSWORD}@localhost/iam_db" >> "$CONFIG_DIR/.env"
}

# Install Python dependencies
install_python_deps() {
    echo -e "${YELLOW}Installing Python dependencies...${NC}"
    
    # Create virtual environment
    sudo -u "$IAM_USER" python3 -m venv "$IAM_HOME/venv"
    
    # Create requirements.txt
    cat > "$IAM_HOME/requirements.txt" << 'EOF'
fastapi==0.104.1
uvicorn[standard]==0.24.0
sqlalchemy==2.0.23
alembic==1.13.0
psycopg2-binary==2.9.9
argon2-cffi==23.1.0
pyjwt[crypto]==2.8.0
python-multipart==0.0.6
jinja2==3.1.2
click==8.1.7
cryptography==41.0.8
pyotp==2.9.0
qrcode[pil]==7.4.2
webauthn==1.11.1
hvac==2.0.0
redis==5.0.1
celery==5.3.4
pydantic[email]==2.5.0
python-jose[cryptography]==3.3.0
passlib[argon2]==1.7.4
aiofiles==23.2.1
httpx==0.25.2
python-dotenv==1.0.0
slowapi==0.1.9
python-ldap==3.4.3
ldap3==2.9.1
smtplib-ssl==1.0.3
email-validator==2.1.0.post1
bleach==6.1.0
markupsafe==2.1.3
wtforms==3.1.1
EOF
    
    # Install Python packages
    sudo -u "$IAM_USER" "$IAM_HOME/venv/bin/pip" install --upgrade pip
    sudo -u "$IAM_USER" "$IAM_HOME/venv/bin/pip" install -r "$IAM_HOME/requirements.txt"
}

# Create SSL certificates
create_ssl_certs() {
    echo -e "${YELLOW}Creating SSL certificates...${NC}"
    
    # Generate self-signed certificate
    openssl req -x509 -newkey rsa:4096 -keyout "$CONFIG_DIR/ssl/server.key" \
        -out "$CONFIG_DIR/ssl/server.crt" -days 365 -nodes \
        -subj "/C=US/ST=State/L=City/O=Organization/OU=IT Department/CN=iam.local"
    
    # Set permissions
    chmod 600 "$CONFIG_DIR/ssl/server.key"
    chmod 644 "$CONFIG_DIR/ssl/server.crt"
    chown "$IAM_USER:$IAM_GROUP" "$CONFIG_DIR/ssl/server.key"
    chown "$IAM_USER:$IAM_GROUP" "$CONFIG_DIR/ssl/server.crt"
}

# Create configuration files
create_configs() {
    echo -e "${YELLOW}Creating configuration files...${NC}"
    
    # Main configuration
    cat > "$CONFIG_DIR/config.yaml" << EOF
server:
  host: "0.0.0.0"
  port: 8443
  ssl_cert: "/etc/iam/ssl/server.crt"
  ssl_key: "/etc/iam/ssl/server.key"
  workers: 4
  reload: false

database:
  url: "postgresql://iam_user:\${DB_PASSWORD}@localhost/iam_db"
  pool_size: 10
  max_overflow: 20
  pool_timeout: 30

vault:
  url: "http://127.0.0.1:8200"
  token_file: "/etc/iam/vault_token"
  mount_point: "iam_secrets"

security:
  secret_key: "$(openssl rand -hex 32)"
  session_timeout: 3600
  max_login_attempts: 5
  lockout_duration: 300
  password_min_length: 12
  password_require_special: true
  password_require_numbers: true
  password_require_uppercase: true
  jwt_algorithm: "HS256"
  jwt_expiration: 3600

authentication:
  default_aal: "AAL1"
  allow_registration: false
  require_email_verification: true
  totp_issuer: "IAM Tool"

plugins:
  enabled:
    - totp
    - webauthn
    - email
  directory: "/opt/iam/plugins"

logging:
  level: "INFO"
  file: "/var/log/iam/app.log"
  max_bytes: 10485760
  backup_count: 5
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

redis:
  url: "redis://localhost:6379/0"

email:
  smtp_host: "localhost"
  smtp_port: 587
  smtp_user: ""
  smtp_password: ""
  from_email: "noreply@iam.local"

backup:
  directory: "/var/backups/iam"
  retention_days: 30
EOF
    
    # Environment variables
    cat > "$CONFIG_DIR/.env" << EOF
# Generated during installation
SECRET_KEY=$(openssl rand -hex 32)
DATABASE_URL=postgresql://iam_user:$(openssl rand -hex 16)@localhost/iam_db
VAULT_TOKEN_FILE=/etc/iam/vault_token
EOF
    
    # Set permissions
    chmod 600 "$CONFIG_DIR/.env"
    chmod 644 "$CONFIG_DIR/config.yaml"
    chown "$IAM_USER:$IAM_GROUP" "$CONFIG_DIR/config.yaml"
    chown "$IAM_USER:$IAM_GROUP" "$CONFIG_DIR/.env"
}

# Initialize Vault
init_vault() {
    echo -e "${YELLOW}Initializing HashiCorp Vault...${NC}"
    
    # Create vault systemd service
    cat > /etc/systemd/system/vault.service << 'EOF'
[Unit]
Description=HashiCorp Vault
Documentation=https://www.vaultproject.io/docs/
Requires=network-online.target
After=network-online.target
ConditionFileNotEmpty=/etc/vault.d/vault.hcl

[Service]
Type=notify
User=vault
Group=vault
ProtectSystem=full
ProtectHome=read-only
PrivateTmp=yes
PrivateDevices=yes
SecureBits=keep-caps
AmbientCapabilities=CAP_IPC_LOCK
Capabilities=CAP_IPC_LOCK+ep
CapabilityBoundingSet=CAP_SYSLOG CAP_IPC_LOCK
NoNewPrivileges=yes
ExecStart=/usr/local/bin/vault server -config=/etc/vault.d/vault.hcl
ExecReload=/bin/kill -HUP $MAINPID
KillMode=process
Restart=on-failure
RestartSec=5
TimeoutStopSec=30
StartLimitInterval=60
StartLimitBurst=3
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF
    
    # Start Vault
    systemctl daemon-reload
    systemctl start vault
    systemctl enable vault
    
    # Wait for Vault to start
    sleep 5
    
    # Initialize Vault
    export VAULT_ADDR='http://127.0.0.1:8200'
    vault operator init -key-shares=1 -key-threshold=1 > "$CONFIG_DIR/vault_keys.txt"
    
    # Extract unseal key and root token
    UNSEAL_KEY=$(grep 'Unseal Key 1:' "$CONFIG_DIR/vault_keys.txt" | awk '{print $NF}')
    ROOT_TOKEN=$(grep 'Initial Root Token:' "$CONFIG_DIR/vault_keys.txt" | awk '{print $NF}')
    
    # Unseal Vault
    vault operator unseal "$UNSEAL_KEY"
    
    # Store root token
    echo "$ROOT_TOKEN" > "$CONFIG_DIR/vault_token"
    chmod 600 "$CONFIG_DIR/vault_token"
    chown "$IAM_USER:$IAM_GROUP" "$CONFIG_DIR/vault_token"
    
    # Enable secrets engine
    VAULT_TOKEN="$ROOT_TOKEN" vault secrets enable -path=iam_secrets kv-v2
}

# Copy application files
copy_application() {
    echo -e "${YELLOW}Installing IAM application...${NC}"
    
    # This would normally copy files from the repository
    # For now, we'll create the basic structure
    mkdir -p "$IAM_HOME/src"
    touch "$IAM_HOME/src/__init__.py"
    
    # Create basic main application file
    cat > "$IAM_HOME/src/main.py" << 'EOF'
#!/usr/bin/env python3
"""
IAM Tool - Main Application Entry Point
"""
import uvicorn
from app import create_app

if __name__ == "__main__":
    app = create_app()
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8443,
        ssl_keyfile="/etc/iam/ssl/server.key",
        ssl_certfile="/etc/iam/ssl/server.crt",
        workers=4
    )
EOF
    
    chmod +x "$IAM_HOME/src/main.py"
    chown -R "$IAM_USER:$IAM_GROUP" "$IAM_HOME/src"
}

# Create systemd service
create_systemd_service() {
    echo -e "${YELLOW}Creating systemd service...${NC}"
    
    cat > /etc/systemd/system/iam.service << EOF
[Unit]
Description=IAM Tool Service
After=network.target postgresql.service vault.service redis.service
Wants=postgresql.service vault.service redis.service

[Service]
Type=exec
User=$IAM_USER
Group=$IAM_GROUP
WorkingDirectory=$IAM_HOME
Environment=PATH=$IAM_HOME/venv/bin
Environment=PYTHONPATH=$IAM_HOME/src
ExecStart=$IAM_HOME/venv/bin/python $IAM_HOME/src/main.py
ExecReload=/bin/kill -s HUP \$MAINPID
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=iam

# Security settings
NoNewPrivileges=yes
ProtectHome=yes
ProtectSystem=strict
ReadWritePaths=$LOG_DIR /var/lib/iam /tmp
PrivateTmp=yes
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectControlGroups=yes

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl daemon-reload
}

# Create CLI tool
create_cli() {
    echo -e "${YELLOW}Creating CLI tool...${NC}"
    
    cat > /usr/local/bin/iamctl << 'EOF'
#!/usr/bin/env python3
"""
IAM Control CLI Tool
"""
import sys
import os

# Add IAM path to Python path
sys.path.insert(0, '/opt/iam/src')

from cli.main import main

if __name__ == '__main__':
    main()
EOF
    
    chmod +x /usr/local/bin/iamctl
}

# Setup nginx reverse proxy
setup_nginx() {
    echo -e "${YELLOW}Configuring Nginx reverse proxy...${NC}"
    
    # Backup original nginx config
    cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.backup
    
    # Create IAM site configuration
    cat > /etc/nginx/sites-available/iam << 'EOF'
server {
    listen 80;
    listen [::]:80;
    server_name _;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name _;

    ssl_certificate /etc/iam/ssl/server.crt;
    ssl_certificate_key /etc/iam/ssl/server.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;

    location / {
        proxy_pass https://127.0.0.1:8443;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_ssl_verify off;
    }

    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
EOF
    
    # Enable site
    if [[ "$OS" == "ubuntu" || "$OS" == "debian" ]]; then
        ln -sf /etc/nginx/sites-available/iam /etc/nginx/sites-enabled/
        rm -f /etc/nginx/sites-enabled/default
    fi
    
    # Test configuration
    nginx -t && systemctl restart nginx
}

# Create initial admin user
create_admin_user() {
    echo -e "${YELLOW}Creating initial admin user...${NC}"
    
    # This would be done through the application
    # For now, we'll create a placeholder
    cat > "$CONFIG_DIR/initial_admin.txt" << EOF
Initial Admin Credentials:
Username: admin
Password: changeme123!

Please change this password immediately after first login.
Access the dashboard at: https://$(hostname -f):8443
EOF
    
    chmod 600 "$CONFIG_DIR/initial_admin.txt"
    chown "$IAM_USER:$IAM_GROUP" "$CONFIG_DIR/initial_admin.txt"
}

# Create backup directories and scripts
setup_backup() {
    echo -e "${YELLOW}Setting up backup system...${NC}"
    
    mkdir -p /var/backups/iam
    chown "$IAM_USER:$IAM_GROUP" /var/backups/iam
    
    # Create backup script
    cat > /usr/local/bin/iam-backup << 'EOF'
#!/bin/bash
# IAM Backup Script

BACKUP_DIR="/var/backups/iam"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="iam_backup_${DATE}.tar.gz"

echo "Starting IAM backup..."

# Create temporary directory
TEMP_DIR=$(mktemp -d)
cd "$TEMP_DIR"

# Backup database
sudo -u postgres pg_dump iam_db > iam_db.sql

# Backup configuration
cp -r /etc/iam config

# Backup Vault data (if unsealed)
if vault status >/dev/null 2>&1; then
    vault kv export -format=json iam_secrets/ > vault_secrets.json 2>/dev/null || true
fi

# Create archive
tar -czf "$BACKUP_DIR/$BACKUP_FILE" *

# Cleanup
cd /
rm -rf "$TEMP_DIR"

echo "Backup completed: $BACKUP_DIR/$BACKUP_FILE"

# Clean old backups (keep last 30 days)
find "$BACKUP_DIR" -name "iam_backup_*.tar.gz" -mtime +30 -delete
EOF
    
    chmod +x /usr/local/bin/iam-backup
    
    # Create daily backup cron job
    echo "0 2 * * * root /usr/local/bin/iam-backup" > /etc/cron.d/iam-backup
}

# Final setup and start services
finalize_installation() {
    echo -e "${YELLOW}Finalizing installation...${NC}"
    
    # Start and enable services
    systemctl enable redis-server || systemctl enable redis
    systemctl start redis-server || systemctl start redis
    
    systemctl enable nginx
    systemctl start nginx
    
    systemctl enable iam
    # Note: We don't start IAM service here as the application code needs to be complete
    
    # Create log rotation
    cat > /etc/logrotate.d/iam << 'EOF'
/var/log/iam/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 iam iam
    postrotate
        systemctl reload iam
    endscript
}
EOF
    
    # Set up firewall rules
    if command -v ufw &> /dev/null; then
        ufw allow 80/tcp
        ufw allow 443/tcp
        ufw allow 8443/tcp
        ufw --force enable
    elif command -v firewall-cmd &> /dev/null; then
        firewall-cmd --add-port=80/tcp --permanent
        firewall-cmd --add-port=443/tcp --permanent
        firewall-cmd --add-port=8443/tcp --permanent
        firewall-cmd --reload
    fi
    
    echo -e "${GREEN}IAM Tool installation completed successfully!${NC}"
    echo
    echo -e "${BLUE}Next steps:${NC}"
    echo "1. Review configuration: $CONFIG_DIR/config.yaml"
    echo "2. Check initial admin credentials: $CONFIG_DIR/initial_admin.txt"
    echo "3. Start the service: systemctl start iam"
    echo "4. Access the dashboard: https://$(hostname -f):8443"
    echo "5. Change the default admin password"
    echo
    echo -e "${YELLOW}Important files:${NC}"
    echo "- Configuration: $CONFIG_DIR/config.yaml"
    echo "- Logs: $LOG_DIR/"
    echo "- SSL certificates: $CONFIG_DIR/ssl/"
    echo "- Vault keys: $CONFIG_DIR/vault_keys.txt (KEEP SECURE!)"
    echo
    echo -e "${RED}Security Notice:${NC}"
    echo "- Change default passwords immediately"
    echo "- Secure the Vault keys file"
    echo "- Consider using proper SSL certificates"
    echo "- Review firewall settings"
}

# Main installation function
main() {
    print_banner
    
    echo -e "${BLUE}Starting IAM Tool installation...${NC}"
    echo
    
    check_root
    detect_os
    
    echo -e "${YELLOW}This will install the IAM Tool with the following components:${NC}"
    echo "- PostgreSQL database"
    echo "- HashiCorp Vault"
    echo "- Redis cache"
    echo "- Nginx reverse proxy"
    echo "- Python application"
    echo "- CLI tools"
    echo
    
    read -p "Continue with installation? [y/N] " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Installation cancelled."
        exit 1
    fi
    
    install_dependencies
    create_user_and_dirs
    install_vault
    setup_postgresql
    install_python_deps
    create_ssl_certs
    create_configs
    init_vault
    copy_application
    create_systemd_service
    create_cli
    setup_nginx
    create_admin_user
    setup_backup
    finalize_installation
}

# Run main function
main "$@"