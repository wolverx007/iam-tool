Factory Portal — Final Bundle
Workflow:
- Login redirects to Keycloak.
- Admin: password -> Keycloak TOTP (required) -> security question (app-level) -> admin dashboard.
- Manufacture: initially KYC pending; upload single PDF; admin approves -> role 'manufacture' assigned and TOTP required -> on next login user sets TOTP and gains access.
- Employee: password only.

Demo creds:
- admin1 / AdminPass123
- manuf1 / ManufPass123
- emp1 / EmpPass123
