<?php require __DIR__ . '/common.php'; $user = $_SERVER['REMOTE_USER'] ?? claim('preferred_username',''); $sub = claim('sub',''); $pdo=db();
$stmt=$pdo->prepare('SELECT * FROM kyc_requests WHERE sub=?'); $stmt->execute([$sub]); $rec=$stmt->fetch(PDO::FETCH_ASSOC); ?>
<!doctype html><html><head><meta charset="utf-8"><title>KYC Center</title></head><body><h2>KYC Center</h2>
<p>User: <?=htmlspecialchars($user)?></p>
<?php if($rec): ?><p>Status: <?=htmlspecialchars($rec['status'])?></p><?php endif; ?>
<form method="post" action="/secure/submit_kyc.php" enctype="multipart/form-data"><label>PDF only<input type="file" name="kyc_doc" accept="application/pdf" required></label><br/><label>Notes<input name="notes"></label><br/><button>Submit</button></form>
<p><a href="/secure/redirect_uri?logout=/loggedout.html">Logout</a></p></body></html>