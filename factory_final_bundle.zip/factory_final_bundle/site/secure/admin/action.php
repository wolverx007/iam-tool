<?php require __DIR__ . '/../secure/common.php'; require_role('admin');
$do = $_GET['do'] ?? ''; $sub = $_GET['sub'] ?? ''; if(!$sub){ http_response_code(400); echo "Missing"; exit; }
$pdo=db();
if($do==='reject'){ $stmt=$pdo->prepare('UPDATE kyc_requests SET status="rejected", reason="Rejected by admin", updated_at=:ts WHERE sub=:sub'); $stmt->execute([':ts'=>now_iso(),':sub'=>$sub]); header('Location: review.php'); exit; }
if($do==='approve'){
  try{
    $role = kc_role_representation('manufacture');
    $rem = kc_role_representation('kyc_pending');
    kc_add_realm_role_to_user_by_id($sub,$role);
    kc_remove_realm_role_from_user_by_id($sub,$rem);
    kc_set_required_action_configure_totp($sub);
    $stmt=$pdo->prepare('UPDATE kyc_requests SET status="approved", updated_at=:ts WHERE sub=:sub'); $stmt->execute([':ts'=>now_iso(),':sub'=>$sub]);
    header('Location: review.php'); exit;
  }catch(Exception $e){ http_response_code(500); echo "Error: ".htmlspecialchars($e->getMessage()); exit; }
} ?>