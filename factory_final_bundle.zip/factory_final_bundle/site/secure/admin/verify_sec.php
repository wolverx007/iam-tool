<?php require __DIR__ . '/../secure/common.php'; $user=$_SERVER['REMOTE_USER']??claim('preferred_username',''); $sub=claim('sub','');
$pdo=db(); $stmt=$pdo->prepare('SELECT * FROM admin_sec WHERE sub=?'); $stmt->execute([$sub]); $r=$stmt->fetch();
if(!$r){ header('Location: setup_sec.php'); exit; }
if($_SERVER['REQUEST_METHOD']==='POST'){ $ans=$_POST['answer']??''; if(password_verify($ans,$r['answer_hash'])){ session_start(); $_SESSION['admin_verified']=$sub; header('Location: /landing/admin.html'); exit; } $err="Incorrect"; }
?>
<!doctype html><html><body><h3>Answer security question</h3><p><?=htmlspecialchars($r['question'])?></p><form method="post"><input name="answer" type="password"><button>Submit</button></form><?php if(isset($err)) echo "<p>$err</p>"; ?></body></html>