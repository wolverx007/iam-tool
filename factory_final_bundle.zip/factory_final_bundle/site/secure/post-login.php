<?php
require __DIR__ . '/common.php';
header('Cache-Control:no-store');
$roles = realm_roles();
$user = $_SERVER['REMOTE_USER'] ?? claim('preferred_username','');
$sub = claim('sub','');

// Admin flow
if(in_array('admin',$roles,true)){
  $pdo = db();
  $stmt = $pdo->prepare('SELECT * FROM admin_sec WHERE sub=?');
  $stmt->execute([$sub]); $rec=$stmt->fetch(PDO::FETCH_ASSOC);
  if(!$rec){ header('Location: /secure/admin/setup_sec.php?u='.urlencode($user)); exit; }
  session_start();
  if(!isset($_SESSION['admin_verified']) || $_SESSION['admin_verified']!==$sub){
    header('Location: /secure/admin/verify_sec.php?u='.urlencode($user)); exit;
  }
  header('Location: /landing/admin.html?u='.urlencode($user)); exit;
}

// Manufacture flow
if(in_array('manufacture',$roles,true)){
  $pdo = db();
  $stmt = $pdo->prepare('SELECT status FROM kyc_requests WHERE sub = ?');
  $stmt->execute([$sub]); $r=$stmt->fetch(PDO::FETCH_ASSOC);
  if(!$r || $r['status']!=='approved'){ header('Location: /secure/kyc.php?u='.urlencode($user)); exit; }
  header('Location: /landing/manufacture.html?u='.urlencode($user)); exit;
}

// Employee
if(in_array('employee',$roles,true)){ header('Location: /landing/employee.html?u='.urlencode($user)); exit; }

header('Location: /landing/guest.html'); exit;
?>