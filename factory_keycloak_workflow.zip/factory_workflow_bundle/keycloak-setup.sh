#!/usr/bin/env bash
set -euo pipefail

KC_HOME="/opt/keycloak"
KC_HTTP_PORT="${KC_HTTP_PORT:-8080}"
REALM="${REALM:-FactoryRealm}"
SITE_DOMAIN="${SITE_DOMAIN:-YOUR_DOMAIN_OR_IP}"
ADMIN_USER="${ADMIN_USER:-admin}"
ADMIN_PASS="${ADMIN_PASS:-Admin123!}"

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y jq curl

${KC_HOME}/bin/kcadm.sh config credentials --server "http://127.0.0.1:${KC_HTTP_PORT}" --realm master --user "${ADMIN_USER}" --password "${ADMIN_PASS}"

if ! ${KC_HOME}/bin/kcadm.sh get realms/${REALM} >/dev/null 2>&1; then
  ${KC_HOME}/bin/kcadm.sh create realms -s realm="${REALM}" -s enabled=true -s registrationAllowed=true -s loginWithEmailAllowed=true     -s otpPolicyType=totp -s otpPolicyAlgorithm=HmacSHA1 -s otpPolicyDigits=6 -s otpPolicyPeriod=30
else
  ${KC_HOME}/bin/kcadm.sh update realms/${REALM} -s registrationAllowed=true -s loginWithEmailAllowed=true     -s otpPolicyType=totp -s otpPolicyAlgorithm=HmacSHA1 -s otpPolicyDigits=6 -s otpPolicyPeriod=30
fi

${KC_HOME}/bin/kcadm.sh update authentication/required-actions/CONFIGURE_TOTP -r "${REALM}" -s defaultAction=true || true

for role in super-admin manufacturer-admin employee guest kyc_pending; do
  ${KC_HOME}/bin/kcadm.sh create roles -r "${REALM}" -s name="${role}" >/dev/null 2>&1 || true
done

${KC_HOME}/bin/kcadm.sh add-roles -r "${REALM}" --rname default-roles-"${REALM}" --rolename kyc_pending || true

if ! ${KC_HOME}/bin/kcadm.sh get clients -r "${REALM}" -q clientId="apache-site" | jq -e '.[0].id' >/dev/null; then
  cat >/tmp/webclient.json <<JSON
{ "clientId": "apache-site", "protocol": "openid-connect", "publicClient": false, "standardFlowEnabled": true,
  "directAccessGrantsEnabled": false, "serviceAccountsEnabled": false, "enabled": true,
  "redirectUris": ["http://${SITE_DOMAIN}/secure/redirect_uri","http://${SITE_DOMAIN}/*"],
  "webOrigins": ["+"], "attributes": {"post.logout.redirect.uris":"+","pkce.code.challenge.method":"S256"}
}
JSON
  ${KC_HOME}/bin/kcadm.sh create clients -r "${REALM}" -f /tmp/webclient.json
fi
WEB_UUID=$(${KC_HOME}/bin/kcadm.sh get clients -r "${REALM}" -q clientId="apache-site" | jq -r '.[0].id')
WEB_SECRET_JSON=$(${KC_HOME}/bin/kcadm.sh get clients/${WEB_UUID}/client-secret -r "${REALM}")
WEB_SECRET=$(echo "${WEB_SECRET_JSON}" | jq -r '.value')
echo -n "${WEB_SECRET}" > /root/keycloak_apache_client_secret.txt
chmod 600 /root/keycloak_apache_client_secret.txt

if ! ${KC_HOME}/bin/kcadm.sh get clients -r "${REALM}" -q clientId="app-admin" | jq -e '.[0].id' >/dev/null; then
  cat >/tmp/appadmin.json <<JSON
{ "clientId": "app-admin", "protocol": "openid-connect", "publicClient": false, "serviceAccountsEnabled": true,
  "standardFlowEnabled": false, "directAccessGrantsEnabled": false, "enabled": true }
JSON
  ${KC_HOME}/bin/kcadm.sh create clients -r "${REALM}" -f /tmp/appadmin.json
fi
APP_UUID=$(${KC_HOME}/bin/kcadm.sh get clients -r "${REALM}" -q clientId="app-admin" | jq -r '.[0].id')
APP_SECRET_JSON=$(${KC_HOME}/bin/kcadm.sh get clients/${APP_UUID}/client-secret -r "${REALM}")
APP_SECRET=$(echo "${APP_SECRET_JSON}" | jq -r '.value')
echo -n "${APP_SECRET}" > /root/keycloak_app_admin_client_secret.txt
chmod 600 /root/keycloak_app_admin_client_secret.txt

REALM_MGMT_CLIENT_ID=$(${KC_HOME}/bin/kcadm.sh get clients -r "${REALM}" -q clientId=realm-management | jq -r '.[0].id')
SA_USER_ID=$(${KC_HOME}/bin/kcadm.sh get clients/${APP_UUID}/service-account-user -r "${REALM}" | jq -r '.id')
${KC_HOME}/bin/kcadm.sh add-roles -r "${REALM}" --uid "${SA_USER_ID}" --cclientid realm-management --rolename manage-users || true
${KC_HOME}/bin/kcadm.sh add-roles -r "${REALM}" --uid "${SA_USER_ID}" --cclientid realm-management --rolename view-users || true

if ! ${KC_HOME}/bin/kcadm.sh get users -r "${REALM}" -q username="superadmin1" | jq -e '.[0].id' >/dev/null; then
  ${KC_HOME}/bin/kcadm.sh create users -r "${REALM}" -s username="superadmin1" -s enabled=true -s email="superadmin@example.com"
  SA_ID=$(${KC_HOME}/bin/kcadm.sh get users -r "${REALM}" -q username="superadmin1" | jq -r '.[0].id')
  ${KC_HOME}/bin/kcadm.sh update users/${SA_ID}/reset-password -r "${REALM}" -s type=password -s value="Sup3rAdmin!" -s temporary=false
  ${KC_HOME}/bin/kcadm.sh add-roles -r "${REALM}" --uusername "superadmin1" --rolename "super-admin"
fi

echo "apache-site client secret: $(cat /root/keycloak_apache_client_secret.txt)"
echo "app-admin client secret: $(cat /root/keycloak_app_admin_client_secret.txt)"
