<?php
declare(strict_types=1);
date_default_timezone_set('UTC');

$BASE_URL = getenv('FACTORY_BASE_URL') ?: 'http://192.168.1.12';
$KEYCLOAK_BASE = getenv('KEYCLOAK_BASE') ?: 'http://127.0.0.1:8080';
$REALM = getenv('FACTORY_REALM') ?: 'FactoryRealm';
$ADMIN_CLIENT_ID = getenv('ADMIN_CLIENT_ID') ?: 'app-admin';
$ADMIN_CLIENT_SECRET = getenv('ADMIN_CLIENT_SECRET') ?: 'PASTE_APP_ADMIN_CLIENT_SECRET_HERE';

$DATA_DIR = __DIR__ . '/../data';
$DB_PATH = $DATA_DIR . '/app.db';
if (!is_dir($DATA_DIR)) { @mkdir($DATA_DIR, 0775, true); }

function db() : PDO {
  global $DB_PATH;
  static $pdo = null;
  if ($pdo === null) {
    $pdo = new PDO('sqlite:' . $DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec('CREATE TABLE IF NOT EXISTS kyc_requests (
      sub TEXT PRIMARY KEY,
      username TEXT,
      desired_role TEXT,
      status TEXT,
      reason TEXT,
      doc_path TEXT,
      created_at TEXT,
      updated_at TEXT
    )');
  }
  return $pdo;
}

function claim($name, $default=null) {
  $key = 'OIDC_CLAIM_' . $name;
  if (isset($_SERVER[$key])) return $_SERVER[$key];
  return $default;
}
function realm_roles() : array {
  $ra = claim('realm_access', '');
  if ($ra) {
    $decoded = json_decode($ra, true);
    if (json_last_error() === JSON_ERROR_NONE && isset($decoded['roles'])) {
      return $decoded['roles'];
    }
  }
  if (isset($_SERVER['OIDC_CLAIM_roles'])) {
    $raw = $_SERVER['OIDC_CLAIM_roles'];
    if (is_string($raw)) {
      return array_values(array_filter(array_map('trim', preg_split('/[\s,]+/', $raw))));
    }
  }
  return [];
}
function has_role($r) : bool { return in_array($r, realm_roles(), true); }
function require_role($r) {
  if (!has_role($r)) { http_response_code(403); echo "Forbidden (need role: $r)"; exit; }
}

function kc_admin_token() : string {
  global $KEYCLOAK_BASE, $REALM, $ADMIN_CLIENT_ID, $ADMIN_CLIENT_SECRET;
  if ($ADMIN_CLIENT_SECRET === 'PASTE_APP_ADMIN_CLIENT_SECRET_HERE') {
    throw new Exception('ADMIN_CLIENT_SECRET not configured. Edit site/secure/common.php');
  }
  $url = $KEYCLOAK_BASE . '/realms/' . rawurlencode($REALM) . '/protocol/openid-connect/token';
  $post = http_build_query([
    'grant_type' => 'client_credentials',
    'client_id' => $ADMIN_CLIENT_ID,
    'client_secret' => $ADMIN_CLIENT_SECRET,
  ]);
  $opts = ['http'=>['method'=>'POST','header'=>"Content-Type: application/x-www-form-urlencoded\r\n",'content'=>$post]];
  $resp = file_get_contents($url, false, stream_context_create($opts));
  if ($resp === false) throw new Exception('Failed to get admin token');
  $json = json_decode($resp, true);
  if (!isset($json['access_token'])) throw new Exception('No access_token from admin client');
  return $json['access_token'];
}

function http_json($method, $url, $token, $payload=null) {
  $headers = "Authorization: Bearer $token\r\nContent-Type: application/json\r\n";
  $opts = ['http'=>['method'=>$method,'header'=>$headers,'ignore_errors'=>true]];
  if ($payload !== null) $opts['http']['content'] = json_encode($payload);
  $ctx = stream_context_create($opts);
  $resp = file_get_contents($url, false, $ctx);
  $code = 0;
  if (isset($http_response_header[0]) && preg_match('~\s(\d{{3})\s~', $http_response_header[0], $m)) $code = (int)$m[1];
  return [$code, $resp];
}

function kc_role_representation(string $role_name) {
  global $KEYCLOAK_BASE, $REALM;
  $token = kc_admin_token();
  $url = $KEYCLOAK_BASE . '/admin/realms/' . rawurlencode($REALM) . '/roles/' . rawurlencode($role_name);
  [$code, $resp] = http_json('GET', $url, $token);
  if ($code !== 200) throw new Exception("Failed to fetch role $role_name ($code)");
  return json_decode($resp, true);
}
function kc_add_realm_role_to_user(string $user_id, array $role) {
  global $KEYCLOAK_BASE, $REALM;
  $token = kc_admin_token();
  $url = $KEYCLOAK_BASE . '/admin/realms/' . rawurlencode($REALM) . '/users/' . rawurlencode($user_id) . '/role-mappings/realm';
  [$code, $resp] = http_json('POST', $url, $token, [$role]);
  if (!in_array($code, [204,201])) throw new Exception("Add role failed ($code): $resp");
}
function kc_remove_realm_role_from_user(string $user_id, array $role) {
  global $KEYCLOAK_BASE, $REALM;
  $token = kc_admin_token();
  $url = $KEYCLOAK_BASE . '/admin/realms/' . rawurlencode($REALM) . '/users/' . rawurlencode($user_id) . '/role-mappings/realm';
  [$code, $resp] = http_json('DELETE', $url, $token, [$role]);
  if (!in_array($code, [204,200])) throw new Exception("Remove role failed ($code): $resp");
}
function now_iso() { return gmdate('Y-m-d\TH:i:s\Z'); }
?>