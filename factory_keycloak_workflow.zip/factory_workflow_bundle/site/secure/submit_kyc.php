<?php require __DIR__ . '/common.php';
$user=$_SERVER['REMOTE_USER']??claim('preferred_username',''); $sub=claim('sub',''); if(!$sub){ http_response_code(400); echo "No subject"; exit; }
$desired=$_POST['desired_role']??''; $allowed=['manufacturer-admin','employee']; if(!in_array($desired,$allowed,true)){ http_response_code(400); echo "Invalid desired role"; exit; }
if(!isset($_FILES['kyc_doc'])||$_FILES['kyc_doc']['error']!==UPLOAD_ERR_OK){ http_response_code(400); echo "Upload error"; exit; }
$size=(int)$_FILES['kyc_doc']['size']; if($size>5*1024*1024){ http_response_code(400); echo "File too large"; exit; }
$ext=strtolower(pathinfo($_FILES['kyc_doc']['name'],PATHINFO_EXTENSION)); if(!in_array($ext,['pdf','jpg','jpeg','png'],true)){ http_response_code(400); echo "Invalid file type"; exit; }
$kycdir=__DIR__.'/../data/kyc/'.preg_replace('~[^a-zA-Z0-9_-]~','_', $sub); @mkdir($kycdir,0770,true); $dest=$kycdir.'/doc_'.time().'.'.$ext;
if(!move_uploaded_file($_FILES['kyc_doc']['tmp_name'],$dest)){ http_response_code(500); echo "Failed to store file"; exit; }
$pdo=db(); $stmt=$pdo->prepare('INSERT INTO kyc_requests (sub,username,desired_role,status,reason,doc_path,created_at,updated_at)
VALUES (:sub,:username,:desired_role,"pending","",:doc_path,:ts,:ts)
ON CONFLICT(sub) DO UPDATE SET desired_role=:desired_role2,status="pending",reason="",doc_path=:doc_path2,updated_at=:ts2');
$ts=gmdate('Y-m-d\TH:i:s\Z');
$stmt->execute([':sub'=>$sub,':username'=>$user,':desired_role'=>$desired,':doc_path'=>$dest,':ts'=>$ts,':desired_role2'=>$desired,':doc_path2'=>$dest,':ts2'=>$ts]);
header('Location: /secure/kyc.php'); exit; ?>