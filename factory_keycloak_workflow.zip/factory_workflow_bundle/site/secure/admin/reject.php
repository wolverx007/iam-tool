<?php require __DIR__ . '/../common.php'; require_role('super-admin');
$sub=$_GET['sub']??''; if(!$sub){ http_response_code(400); echo "Missing sub"; exit; }
$pdo=db(); $stmt=$pdo->prepare('UPDATE kyc_requests SET status="rejected", reason="Rejected by admin", updated_at=:ts WHERE sub=:sub');
$stmt->execute([':ts'=>now_iso(), ':sub'=>$sub]); header('Location: /secure/admin/review.php'); ?>