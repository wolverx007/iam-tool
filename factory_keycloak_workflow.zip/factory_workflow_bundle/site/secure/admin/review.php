<?php require __DIR__ . '/../common.php'; require_role('super-admin'); $pdo=db();
$rows=$pdo->query('SELECT * FROM kyc_requests ORDER BY updated_at DESC')->fetchAll(PDO::FETCH_ASSOC); ?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Review</title>
<style>body{font-family:system-ui;background:#0f172a;color:#e5e7eb;margin:0}.wrap{max-width:1000px;margin:2rem auto;padding:1rem}
table{width:100%;border-collapse:collapse}th,td{border-bottom:1px solid #1f2937;padding:.6rem;text-align:left}
a.btn{display:inline-block;background:#2563eb;color:white;text-decoration:none;font-weight:700;border-radius:10px;padding:.4rem .6rem;margin:.1rem}.muted{color:#9ca3af}</style></head>
<body><div class="wrap"><h2>🛡️ KYC Review</h2><p class="muted">Approve or reject pending KYC requests.</p>
<table><tr><th>User</th><th>Sub</th><th>Desired Role</th><th>Status</th><th>Doc</th><th>Actions</th></tr>
<?php foreach($rows as $r): ?><tr>
<td><?=htmlspecialchars($r['username']?:'-')?></td>
<td><code><?=htmlspecialchars($r['sub'])?></code></td>
<td><?=htmlspecialchars($r['desired_role'])?></td>
<td><?=htmlspecialchars($r['status'])?></td>
<td><?php if($r['doc_path']): ?><a class="btn" href="<?=str_replace($_SERVER['DOCUMENT_ROOT'],'',$r['doc_path'])?>" target="_blank">Open</a><?php endif; ?></td>
<td><a class="btn" href="approve.php?sub=<?=urlencode($r['sub'])?>&role=<?=urlencode($r['desired_role'])?>">Approve</a>
<a class="btn" href="reject.php?sub=<?=urlencode($r['sub'])?>">Reject</a></td>
</tr><?php endforeach; ?></table><p><a href="/">Home</a></p></div></body></html>