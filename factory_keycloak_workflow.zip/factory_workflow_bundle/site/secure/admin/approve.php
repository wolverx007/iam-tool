<?php require __DIR__ . '/../common.php'; require_role('super-admin');
$sub=$_GET['sub']??''; $role=$_GET['role']??'manufacturer-admin'; if(!$sub){ http_response_code(400); echo "Missing sub"; exit; }
if(!in_array($role,['manufacturer-admin','employee'],true)){ http_response_code(400); echo "Invalid role"; exit; }
try{ $user_id=$sub; $add=kc_role_representation($role); $rem=kc_role_representation('kyc_pending');
kc_add_realm_role_to_user($user_id,$add); kc_remove_realm_role_from_user($user_id,$rem);
$pdo=db(); $stmt=$pdo->prepare('UPDATE kyc_requests SET status="approved", updated_at=:ts WHERE sub=:sub'); $stmt->execute([':ts'=>now_iso(),':sub'=>$sub]);
header('Location: /secure/admin/review.php'); } catch(Exception $e){ http_response_code(500); echo "Error: ".htmlspecialchars($e->getMessage()); } ?>