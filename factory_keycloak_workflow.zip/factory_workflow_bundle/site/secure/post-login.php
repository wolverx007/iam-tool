<?php require __DIR__ . '/common.php'; header('Cache-Control: no-store');
$priority=['super-admin'=>'/landing/admin.html','manufacturer-admin'=>'/landing/manufacture.html','employee'=>'/landing/employee.html','kyc_pending'=>'/secure/kyc.php'];
$roles=realm_roles(); foreach($priority as $role=>$dest){ if(in_array($role,$roles,true)){ $user=$_SERVER['REMOTE_USER']??claim('preferred_username',''); header('Location: '.$dest.'?u='.urlencode($user)); exit; } }
header('Location: /landing/guest.html'); exit; ?>