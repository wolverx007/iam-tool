<?php require __DIR__ . '/common.php'; $user=$_SERVER['REMOTE_USER']??claim('preferred_username',''); $sub=claim('sub',''); ?>
<!doctype html><html><head><meta charset="utf-8"><title>KYC Center</title>
<style>body{font-family:system-ui;background:#0f172a;color:#e5e7eb;margin:0}.wrap{max-width:900px;margin:2rem auto;padding:1rem}
.card{background:#111827;border:1px solid #1f2937;border-radius:16px;padding:1.2rem}label{display:block;margin-top:.7rem}
input,select,button{padding:.6rem;border-radius:10px;border:1px solid #374151;background:#0b1220;color:#e5e7eb}.muted{color:#9ca3af}.row{display:flex;gap:1rem;flex-wrap:wrap}</style></head>
<body><div class="wrap"><div class="card"><h2>🧾 KYC Center</h2><p>User: <code><?=htmlspecialchars($user)?></code></p>
<?php $pdo=db(); $stmt=$pdo->prepare('SELECT * FROM kyc_requests WHERE sub=?'); $stmt->execute([$sub]); $rec=$stmt->fetch(PDO::FETCH_ASSOC);
if($rec){ echo "<p>Status: <strong>".htmlspecialchars($rec['status'])."</strong>"; if(!empty($rec['reason'])) echo " — ".htmlspecialchars($rec['reason']); echo "</p>";
 if($rec['status']==='rejected'){ echo "<p class='muted'>You may resubmit your documents below.</p>"; }
 elseif($rec['status']==='approved'){ echo "<p class='muted'>Approved for role '".htmlspecialchars($rec['desired_role'])."'. <a href='/secure/post-login.php'>Re-enter</a>.</p>"; } } ?>
<hr/><form method="post" action="/secure/submit_kyc.php" enctype="multipart/form-data">
<div class="row"><div><label>Desired Role</label><select name="desired_role" required>
<option value="manufacturer-admin">Manufacturer Admin</option><option value="employee">Employee</option></select></div>
<div><label>KYC Document (PDF/JPG/PNG ≤ 5MB)</label><input type="file" name="kyc_doc" accept=".pdf,.jpg,.jpeg,.png" required></div></div>
<label>Notes (optional)</label><input type="text" name="notes" placeholder="Any additional info">
<p class="muted">Your data is linked to your Keycloak account and reviewed by a Super Admin.</p><button type="submit">Submit / Resubmit KYC</button></form></div>
<p><a href="/secure/redirect_uri?logout=/loggedout.html">🔓 Logout</a> · <a href="/">Home</a></p></div></body></html>