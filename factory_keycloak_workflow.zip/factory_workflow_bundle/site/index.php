<?php ?><!doctype html>
<html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Factory Portal (RBAC + KYC)</title>
<style>body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,'Helvetica Neue',Arial;background:#0f172a;color:#e5e7eb;margin:0}
header,footer{text-align:center;padding:1.25rem}.wrap{max-width:980px;margin:0 auto;padding:1rem}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:1rem}
.card{background:#111827;border:1px solid #1f2937;border-radius:16px;padding:1.5rem}
a.btn{display:inline-block;background:#2563eb;color:white;text-decoration:none;font-weight:700;border-radius:12px;padding:.8rem 1rem;margin-top:.5rem}
.muted{color:#9ca3af;font-size:.95rem}code{background:#0b1220;border:1px solid #1f2937;border-radius:8px;padding:.2rem .35rem}
</style></head>
<body>
<header><h1>🏭 Factory Portal</h1><p class="muted">Keycloak OIDC · RBAC · KYC workflow</p></header>
<div class="wrap"><div class="grid">
<div class="card"><h3>Public (Guest)</h3><p>Browse public docs and stats without login.</p><a class="btn" href="/public.html">View Public Page</a></div>
<div class="card"><h3>Sign in</h3><p>Login to access your dashboard. If you don’t have an account, click <em>Register</em> on the Keycloak page.</p>
<a class="btn" href="/secure/post-login.php">🔐 Login</a>
<p class="muted">After login you'll be routed by role:
<code>super-admin</code>, <code>manufacturer-admin</code>, <code>employee</code>, <code>kyc_pending</code>.</p></div>
<div class="card"><h3>Admin Review</h3><p>Super Admins can review/approve KYC requests.</p>
<a class="btn" href="/secure/admin/review.php">🛡️ Admin Review</a><p class="muted">Requires role <code>super-admin</code>.</p></div>
</div></div>
<footer>Keycloak × Apache mod_auth_openidc · Demo</footer></body></html>