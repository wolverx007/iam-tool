# Factory Portal — RBAC + KYC (Keycloak + Apache)

**What you get**
- Roles: `super-admin`, `manufacturer-admin`, `employee`, `guest`, `kyc_pending`
- Self-registration on; default role `kyc_pending`
- OTP (TOTP) required (users set it up on first login)
- KYC upload + approval UI; on approval role is granted via Keycloak Admin API

**Deploy**
```bash
unzip factory_keycloak_workflow.zip
cd factory_workflow_bundle
sudo rsync -av site/ /var/www/factory-site/
sudo cp apache/vhost-factory.conf /etc/apache2/sites-available/factory.conf

# Upgrade Keycloak objects (realm/roles/clients)
sudo bash keycloak-setup.sh

# Update Apache secret and domain in vhost:
sudo nano /etc/apache2/sites-available/factory.conf
# - Replace YOUR_DOMAIN_OR_IP
# - Set OIDCClientSecret to the value printed by keycloak-setup.sh

# Put app-admin secret into PHP:
sudo nano /var/www/factory-site/secure/common.php
# Replace PASTE_APP_ADMIN_CLIENT_SECRET_HERE with /root/keycloak_app_admin_client_secret.txt content

sudo a2ensite factory
sudo a2enmod auth_openidc php*
sudo systemctl reload apache2
sudo chown -R www-data:www-data /var/www/factory-site/data
```

**Login flow**
- New user registers in Keycloak → lands on KYC Center (`kyc_pending`).
- Upload document + choose role (Manufacturer Admin or Employee).
- Super Admin (`superadmin1` / `Sup3rAdmin!`) approves in `/secure/admin/review.php`.
- User re-enters → routed to their role landing.
